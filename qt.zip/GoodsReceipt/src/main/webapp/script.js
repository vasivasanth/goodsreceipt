function view(button) {

    var tdValue =button.closest('tr').querySelectorAll('td'); 
	document.getElementById("id").innerHTML="Receipt ID: "+"<b>"+tdValue[1].textContent.trim()+"</b>";
	document.getElementById("date").innerHTML="Receipt Date: "+"<b>"+tdValue[2].textContent.trim()+"</b>";
	document.getElementById("vendor").innerHTML="Vendor: "+"<b>"+tdValue[3].textContent.trim()+"</b>";
    sendDataToServlet(tdValue[1].textContent.trim());
	
	const over = document.getElementById("list-overlay");
	const popDialog = document.getElementById("list-popupDialog");
		    over.style.display = "block";
		    popDialog.style.display = "block";
		    popDialog.style.opacity = popDialog.style.opacity === "1" ? "0" : "1";
}

function sendDataToServlet(value) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "GRServlet", false);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {			
			          var receiptLineItems = JSON.parse(xhr.responseText);
			          var tbody = document.getElementById("viewTableBody");
			          
					  var rowsHtml = "";
					  receiptLineItems.forEach((item, index)=> {
					      rowsHtml += "<tr>"
					                + "<td>" + (index + 1) + "</td>"
					                + "<td>" + item.productId + "</td>"
					                + "<td>" + item.date + "</td>"
					                + "<td>" + item.quantity + "</td>"
					                + "</tr>";
					  });
					  tbody.innerHTML = rowsHtml;
        }
    };
	console.log(value);
    xhr.send("receiptID=" + encodeURIComponent(value));
}

document.getElementById("list-overlay").addEventListener("click", function(event) {
	const over = document.getElementById("list-overlay");
	const popDialog = document.getElementById("list-popupDialog");
		    over.style.display = "none";
		    popDialog.style.display = "none";
			popDialog.style.opacity = popDialog.style.opacity === "1" ? "0" : "1";
	document.getElementById("viewTableBody").innerHTML = "";
	document.getElementById("id").innerHTML="";
	document.getElementById("date").innerHTML="";
	document.getElementById("vendor").innerHTML="";		
    });