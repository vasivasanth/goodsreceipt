package com.qualiantech.database;
import com.qualiantech.dao.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
public class Main {
	
	private Connection connection;
    public Main(Connection connection) {
        this.connection = connection;
        storeProductInMap();
        storeVendorInMap();
    }

    public  Map<String, String[]> productMap = new LinkedHashMap<>();

    public void storeProductInMap() {
       String sql = "select code, name, uom from product order by code asc";
       try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
            	String a[]=new String[2];
                String productId = rs.getString(1);
                a[0]=rs.getString(2);
                a[1]=rs.getString(3);
                productMap.put(productId, a);
            }
        }
      catch (SQLException e) {
         e.printStackTrace();
      }
    }
    
    public void showProduct() {
    	System.out.println("-----------------------------------");
    	System.out.println("ProductID   ProductName    Uom");
    	System.out.println("-----------------------------------");
    	for (Map.Entry<String, String[]> entry : productMap.entrySet()) {
    		String s="";	
    		String[] productDetail = entry.getValue();
    		if(productDetail[0].length()<15) {
            	for (int i=0;i<(15-productDetail[0].length()); i++) {
            		s +=" ";
            	}
            }
            System.out.println(" " + entry.getKey() + "       " + productDetail[0]+s+productDetail[1] );
        }
    }
    
    //Store and retrieve vendor values
    public  Map<String, String> vendorMap = new LinkedHashMap<>();
    
    public void storeVendorInMap() {
    	String sql = "select code, name from vendor";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);
    		ResultSet rs=stmt.executeQuery() ){
    		while(rs.next()) {
    			String vendorId = rs.getString(1);
    			String vendorName = rs.getString(2);
    			vendorMap.put(vendorId, vendorName);
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}	
    }
    
    public void showVendor() {
    	System.out.println("-------------------------");
    	System.out.println("VendorID  vendorName");
    	System.out.println("-------------------------");
    	for (Map.Entry<String, String> entry : vendorMap.entrySet()) {
            System.out.println(" " + entry.getKey() + "     " + entry.getValue());
        }
    }
    
    //Store line item Primary keys
    public List<String> LineItemPrimaryKey;
    
    public void storeLineitemPK(String receiptID) {
    	
    	LineItemPrimaryKey = new ArrayList<String>();
    	String sql ="select m_inoutline_id from m_inoutline join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id where m_inout.document_id=?";
    	try(PreparedStatement statement = connection.prepareStatement(sql)){
    		statement.setString(1, receiptID);
    		ResultSet resultSet = statement.executeQuery();
    		while(resultSet.next()) {
    			LineItemPrimaryKey.add(resultSet.getString(1));
    		}
            System.out.println(LineItemPrimaryKey);
    	} catch (SQLException e) {
            e.printStackTrace();
        }    	
    }

    //View receipt - inout Table
    public void viewReceiptList(int limit, int offset) {
        String sql = "select vendor.name,* from m_inout join vendor on vendor.vendor_id=m_inout.vendor_id order by m_inout.created desc LIMIT ? OFFSET ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, limit);
            statement.setInt(2, offset);
            ResultSet resultSet = statement.executeQuery();
            System.out.println("--------------------------------------");
            System.out.println("ReceiptID  Date         VendorID");
            System.out.println("--------------------------------------");
            while (resultSet.next()) {
            	Timestamp utcTimestampCreated = resultSet.getTimestamp("created");
            	Timestamp utcTimestampUpdated = resultSet.getTimestamp("updated");
            	Date sqlDate = resultSet.getDate("document_date");  // Retrieve as java.sql.Date
            	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            	String formattedDate = sqlDate.toLocalDate().format(formatter);

            	System.out.println(resultSet.getString("document_id")+"      "
            	                 + formattedDate+"   "
            			         +resultSet.getString(1)+" "
            			         +resultSet.getString("m_inout_id")+" "
            			         +resultSet.getString("isactive")+" "
            			         +resultSet.getString("createdby")+" "
            			         +resultSet.getString("updatedby")+" "
            			         +convertUTCToIndiaTime(utcTimestampCreated)+" "
            			         +convertUTCToIndiaTime(utcTimestampUpdated)+" END");
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void showReceipt(String userInput) {
        String sql = "SELECT product.name,product.uom, *  FROM m_inoutline join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id join product on product.product_id=m_inoutline.product_id  WHERE m_inout.document_id =?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userInput);
            ResultSet resultSet = statement.executeQuery();
       
            System.out.println("Sn "+"ProductName   Date       "+" Quantity"
     		                +"\n-----------------------------------------------");
            int serialNumber=0;
            while (resultSet.next()) {
            	Timestamp utcTimestampCreated = resultSet.getTimestamp("created");
            	Timestamp utcTimestampUpdated = resultSet.getTimestamp("updated");
            	Date sqlDate = resultSet.getDate("expiry_date");  // Retrieve as java.sql.Date
            	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            	String formattedDate = sqlDate.toLocalDate().format(formatter);
                String space="";
                if(resultSet.getString(1).length() < 13) {
                	for (int i=0;i<(13-resultSet.getString(1).length());i++) {
                		space +=" ";
                	}
                }
            	System.out.println((++serialNumber)+"  "
                                 +resultSet.getString(1)+space+" "
            			         + formattedDate+"  "
                                 +resultSet.getInt("quantity")+" "
            			         +resultSet.getString(2)+"  "
                                 +resultSet.getString("m_inoutline_id")+"  "
            			         +resultSet.getString("isactive")+"  "
            			         +resultSet.getString("createdby")+"  "
            			         +resultSet.getString("updatedby")+"  "
            			         +convertUTCToIndiaTime(utcTimestampCreated)+"  "
            			         +convertUTCToIndiaTime(utcTimestampUpdated));
            }
            System.out.println("-----------------------------------------------");
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //viewReceiptByDao
    public void viewReceiptByDao(String userInput) {
        GoodsReceipt dao = null;
        ReceiptLineItem lineitem = null;
        String inout = "select * from m_inout where document_id = ?";
        String inoutline ="select * from m_inoutline where m_inout_id = (select m_inout_id from m_inout where document_id = ?)";

        try (PreparedStatement pstmt1 = connection.prepareStatement(inout);
             PreparedStatement pstmt2 = connection.prepareStatement(inoutline)) {
            
            pstmt2.setString(1, userInput);
            ResultSet rs2 = pstmt2.executeQuery();

            List<ReceiptLineItem> al = new ArrayList<>();

            while (rs2.next()) { 
                lineitem = new ReceiptLineItem();
                lineitem.setInoutlineId(rs2.getString(1));
                lineitem.setIsactive(rs2.getString(2).charAt(0));


                lineitem.setCreated(rs2.getTimestamp(3).toLocalDateTime());
                lineitem.setCreatedby(rs2.getString(4));

                lineitem.setUpadted(rs2.getTimestamp(5).toLocalDateTime());
                lineitem.setUpdatedby(rs2.getString(6));
                lineitem.setReceiptId(rs2.getString(7));
                lineitem.setProductId(rs2.getString(8));
                lineitem.setDate(rs2.getDate(9).toLocalDate());
                lineitem.setQuantity(rs2.getInt(10));
                al.add(lineitem);
            }
            
            pstmt1.setString(1, userInput);
            ResultSet rs1 = pstmt1.executeQuery();
            while (rs1.next()) {
                dao = new GoodsReceipt();
                dao.setInoutId(rs1.getString(1));
                dao.setIsactive(rs1.getString(2).charAt(0));

                dao.setCreated(rs1.getTimestamp(3).toLocalDateTime());
                dao.setCreatedby(rs1.getString(4));


                dao.setUpadted(rs1.getTimestamp(5).toLocalDateTime());
                dao.setUpdatedby(rs1.getString(6));
                dao.setVendorId(rs1.getString(7));
                dao.setReceiptId(rs1.getString(8));
                dao.setDate(rs1.getDate(9).toLocalDate());
                dao.setLineItems(al);
            }
                  
            
            System.out.println("\nReceipt ID : "+userInput+"\n");
            System.out.println(""+dao.getInoutId()+" "
            		             +dao.getIsactive()+" "
            		             +convertUTCToIndiaTime(dao.getCreated())+" "
            		             +dao.getCreatedby()+" "
            		             +convertUTCToIndiaTime(dao.getUpdated())+" "
            		             +dao.getUpdatedby()+" "
            		             +dao.getVendorId()+" "
            		             +dao.getReceiptId()+" "
            		             +dao.getReceiptDate()+" "); 
            System.out.println("\nLine Items: \n");
            for (ReceiptLineItem item : dao.getLineItems()) { 
                System.out.println(item.getInoutlineId()+" "
                		          +item.getIsactive()+" "
                		          +convertUTCToIndiaTime(item.getCreated())+" "
                		          +item.getCreatedby()+" "
                		          +convertUTCToIndiaTime(item.getUpdated())+" "
                		          +item.getUpdatedby()+" "
                		          +item.getReceiptId()+" "
                		          +item.getProductId()+" "
                		          +item.getDate()+" "
                		          +item.getQuantity());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (DateTimeParseException e) {
            e.printStackTrace();
        }
    }
    
    
    //View Stock
    public  void viewProductStock() {
    	String viewProductStockQuery="Select name, stock, uom from product";
    	try(PreparedStatement Stmt = connection.prepareStatement(viewProductStockQuery)){
    		ResultSet rs=Stmt.executeQuery();
    		System.out.println("---------------------------"
    				        +"\nProductName    Stock"
    				        +"\n---------------------------");
    		while(rs.next()) {
    		  String s="";	
    		  if(rs.getString(1).length()<15) {
    			    
                	for (int i=0;i<(15-rs.getString(1).length()); i++) {
                		s +=" ";
                	}
              }
    			System.out.println(rs.getString(1)+s+rs.getInt(2)+" "+rs.getString(3));
    		}
    		System.out.println();
    	}catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //isValidDate
    public static boolean isDateValid(String date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        try {
            LocalDate.parse(date, formatter);
            return true;
        } catch (Exception e) {
            System.out.println("Invalid Date format\n");
        	return false;
        }
    }
    
    //String to localdate format
    public LocalDate stringToLocalDate(String dateStr) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return LocalDate.parse(dateStr, inputFormatter);
    }
    //convert UTC to IST
    public static String convertUTCToIndiaTime(Timestamp utcTimestamp) {
        
    	ZoneId indiaZoneId = ZoneId.of("Asia/Kolkata");
        LocalDateTime localDateTime = utcTimestamp.toLocalDateTime();
        LocalDateTime localDateTimeInIndia = localDateTime.atZone(ZoneId.of("UTC"))
                                            .withZoneSameInstant(indiaZoneId)
                                            .toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
        return localDateTimeInIndia.format(formatter);
    }
    
    public static String convertUTCToIndiaTime(LocalDateTime utcDateTime) {
        ZoneId indiaZoneId = ZoneId.of("Asia/Kolkata");
        ZonedDateTime utcZonedDateTime = utcDateTime.atZone(ZoneOffset.UTC);
        ZonedDateTime indiaZonedDateTime = utcZonedDateTime.withZoneSameInstant(indiaZoneId);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
        return indiaZonedDateTime.format(formatter);
    }

    
    
    //convert IST to UTC
    public static String convertIndiaTimeToUTC() {
        ZoneId indiaZoneId = ZoneId.of("Asia/Kolkata");
        LocalDateTime localDateTimeInIndia = LocalDateTime.now(indiaZoneId);
        ZonedDateTime zonedDateTimeInIndia = ZonedDateTime.of(localDateTimeInIndia, indiaZoneId);
        ZonedDateTime utcDateTime = zonedDateTimeInIndia.withZoneSameInstant(ZoneId.of("UTC"));DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
        return utcDateTime.format(formatter);
    }
    
    
    //Insert into database 
    public void insertIntoDatabase(GoodsReceipt dao) {
    	String insertReceiptQuery="insert into m_inout (createdby, updatedby, document_id, document_date, vendor_id)\n"
    		            	  + "values(?,?,?,?,(select vendor_id from vendor where code = ? ))";
    	
    	
    	String insertLineItemQuery="insert into m_inoutline (createdby, updatedby, m_inout_id, product_id, expiry_date, quantity)\n"
    			               + "values(?, ?, (select m_inout_id from m_inout where document_id = ?), (select product_id from product where code=?), ?, ?)";

        try (
            PreparedStatement receiptStmt = connection.prepareStatement(insertReceiptQuery);
            PreparedStatement lineItemStmt = connection.prepareStatement(insertLineItemQuery);
        ) {
        	connection.setAutoCommit(false);
            Date sqlDate = Date.valueOf(dao.getReceiptDate());
        	
            // Insert DAO information into inout table
            receiptStmt.setString(1, dao.getCreatedby());
            receiptStmt.setString(2, dao.getUpdatedby());
            receiptStmt.setString(3, dao.getReceiptId());
            receiptStmt.setDate(4, sqlDate);
            receiptStmt.setString(5, dao.getVendorId());
            receiptStmt.executeUpdate(); 

            // Insert line items into inoutline table
           for (ReceiptLineItem item : dao.getLineItems()) {
        	   Date expiryDate = Date.valueOf(item.getDate());
                lineItemStmt.setString(1, dao.getCreatedby());
                lineItemStmt.setString(2, dao.getUpdatedby());
                lineItemStmt.setString(3, dao.getReceiptId());
                lineItemStmt.setString(4, item.getProductId());
                lineItemStmt.setDate(5, expiryDate );
                lineItemStmt.setInt(6, item.getQuantity());
                lineItemStmt.addBatch(); 
            }
            lineItemStmt.executeBatch();
            connection.commit();
            System.out.println("Data inserted successfully."); 

        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
     }
    
    
    //Update new line item into database
       public void updateIntoDatabase(GoodsReceipt dao) {
    	String insertLineItemQuery="insert into m_inoutline (createdby, updatedby, m_inout_id, product_id, expiry_date, quantity)\n"
    			               + "values(?, ?, (select m_inout_id from m_inout where document_id = ?), (select product_id from product where code=?), ?, ?)";
        try (
            PreparedStatement lineItemStmt = connection.prepareStatement(insertLineItemQuery);
        ) {
        	connection.setAutoCommit(false);        	
            // Insert line items into inoutline table
           for (ReceiptLineItem item : dao.getLineItems()) {
        	   Date expiryDate = Date.valueOf(item.getDate());
                lineItemStmt.setString(1, dao.getCreatedby());
                lineItemStmt.setString(2, dao.getUpdatedby());
                lineItemStmt.setString(3, dao.getReceiptId());
                lineItemStmt.setString(4, item.getProductId());
                lineItemStmt.setDate(5, expiryDate );
                lineItemStmt.setInt(6, item.getQuantity());
                lineItemStmt.addBatch(); 
            }
            lineItemStmt.executeBatch(); 
            connection.commit();
            System.out.println("Data updated successfully."); 

        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
     }
    
    //update receipt    
    public void updateReceiptDate(String updateReceiptID, String date) {
        updateReceiptField("UPDATE m_inout SET updated =now() at time zone 'UTC', document_date = ? WHERE document_id = ?", updateReceiptID, date);
    }

    public void updateVendorID(String updateReceiptID, String vendor) {
        updateReceiptField("UPDATE m_inout SET updated =now() at time zone 'UTC', vendor_id = (SELECT vendor_id FROM vendor WHERE code = ?) WHERE document_id = ?", updateReceiptID, vendor);
    }

    public void updateReceiptField(String query, String updateReceiptID, String value) {
        try (PreparedStatement updateStmt = connection.prepareStatement(query)) {
        	connection.setAutoCommit(false);
            if (query.contains("document_date")) {
                DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                Date sqlDate = Date.valueOf(LocalDate.parse(value, inputFormatter));
                updateStmt.setDate(1, sqlDate);
            } else {
                updateStmt.setString(1, value);
            }
            updateStmt.setString(2, updateReceiptID);
            updateStmt.executeUpdate();
            
            connection.commit();
            System.out.println("Update successful\n");
        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //Update line items   
    public void updateProductID(String updateReceiptID, String productid, String pk) {
    	updateLineitemFeild("update m_inoutline set updated =now() at time zone 'UTC', product_id = (select product_id from product where code=?) where m_inoutline_id = ?", updateReceiptID, productid, pk);
    }
    public void updateExpiryDate(String updateReceiptID, String date,String pk) {
    	updateLineitemFeild("update m_inoutline set updated =now() at time zone 'UTC', expiry_date = ? where m_inoutline_id = ?", updateReceiptID, date, pk);
    }
    public void updateQuantity(String updateReceiptID, String quantity,String pk) {
    	updateLineitemFeild("update m_inoutline set updated =now() at time zone 'UTC', quantity = ? where m_inoutline_id = ?", updateReceiptID, quantity, pk);
    }
    
    public void updateLineitemFeild(String query, String updateReceiptID, String value, String primarykey) {
	
        try (PreparedStatement updateStmt = connection.prepareStatement(query)) {
        	connection.setAutoCommit(false);
            if (query.contains("expiry_date")) {
                DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                Date sqlDate = Date.valueOf(LocalDate.parse(value, inputFormatter));
                updateStmt.setDate(1, sqlDate);
            } 
            else if(query.contains("product_id")) {
                updateStmt.setString(1, value);
            }
            else if(query.contains("quantity")) {
            	updateStmt.setInt(1, Integer.parseInt(value));
            }
            updateStmt.setString(2, primarykey);
            updateStmt.executeUpdate();
            
            connection.commit();
            System.out.println("Update successful\n");
        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //Delete LineItem
    public void deleteReceipt(String deleteReceiptID) {
    	deleteFeild("delete from m_inout where document_id = ?", deleteReceiptID);
    }
    public void deleteLineItem(String deleteLineitemID) {
    	deleteFeild("delete from m_inoutline where m_inoutline_id = ?", deleteLineitemID);
    }
    public void deleteFeild(String query, String pk) {
    	
        try (PreparedStatement updateStmt = connection.prepareStatement(query)) {
        connection.setAutoCommit(false);
            updateStmt.setString(1, pk);
            updateStmt.executeUpdate(); 
            connection.commit();
            System.out.println("Deleted successfully\n");
        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    //Main method    
	public static void main(String[] args) {
		
		System.out.println("Current utc time: "+convertIndiaTimeToUTC());
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Random randomNumber = new Random();
		 DatabaseConnection dbConnection = new DatabaseConnection();
		 GoodsReceipt dao;
		    
		 try(Connection con = dbConnection.getConnection()){		    
	        Main dbManager = new Main(con);
	        int userInput=0;
	        System.out.println("*****************************"
	        		        +"\n        GOODS RECEIPT        "
	        		        +"\n*****************************");
	        boolean databaseConnected = true;
	        while(databaseConnected){
	        	System.out.println(  "1. View Receipt"
	                              +"\n2. Insert New Receipt"
	        			          +"\n3. Update Receipt"
	        			          +"\n4. Delete Receipt or lineitems"
	        			          +"\n5. Product Stock"
	        			          +"\n6. ViewReceiptByDao"
	        			          +"\n7. Exist...");
	        	databaseConnected=false;
	        	System.out.print("\nEnter a number: ");
	        	userInput=sc.nextInt();
	        	
	        	switch(userInput) {
	            	case 1:
	            		System.out.println("How many receipts do you want to view?");
	            		System.out.print("Limit: ");
	            		int limit=sc.nextInt();
	            		System.out.print("Offset: ");
	            		int offset=sc.nextInt();
	            		dbManager.viewReceiptList(limit, offset);
	        		    System.out.println("Enter a Receipt No: ");
	        		    sc.nextLine();
	        		    String receiptId = sc.nextLine().trim();
	        		    dbManager.showReceipt(receiptId);
	        		    databaseConnected=true;
	        		    System.out.println("Press Enter for Main Page");
	        		    sc.nextLine();
	        		    break;
	        		    
	            	case 2:
	            		String receiptid="GR"+(randomNumber.nextInt(999));//112
	            		dao= new GoodsReceipt("vasanth",receiptid);
	            		
	            		System.out.print("Enter a date (dd-MM-yyyy): ");
	            		String date = sc.next();
	            		if(!isDateValid(date)) {databaseConnected = true;break;}
	            	    dao.setDate(dbManager.stringToLocalDate(date));
	            	    dbManager.showVendor();
	            		System.out.print("Enter vendor ID: ");
	            		String vendorId=sc.next();
	            		dao.setVendorId(vendorId);
	            		
	            		System.out.println("\nReceipt Created: "+dao.getReceiptId()+" "+dao.getReceiptDate()+" "+dbManager.vendorMap.get(dao.getVendorId())+"\n");
	            		boolean check=true;
	            		while(check) {
	            			dbManager.showProduct();
	            			System.out.print("Enter Product ID: ");
	            			String productId=sc.next();
	            			
	            			System.out.print("Enter Expiry Date: ");
	            			String expiryDate=sc.next();
	            			if(!isDateValid(expiryDate)) {check=true; break;}
	            			System.out.print("Enter Quanitity: ");
	            			int quantity =sc.nextInt();
	            			
	            			dao.addLineItem(productId, dbManager.stringToLocalDate(expiryDate), quantity);
	            			
	            			System.out.println("\nAdded Products: ");
	            	        for (ReceiptLineItem item : dao.getLineItems()) {
	            	        	
	            	        	String pid[] = dbManager.productMap.get(item.getProductId());
	            	        	String space="";
	                            if(pid[0].length() < 11) {
	                            	for (int i=0;i<(11-pid[0].length());i++) {
	                            		space +=" ";
	                            	}
	                            }
	            	            System.out.println(pid[0] +space+" "+ item.getDate()+" "+ item.getQuantity());
	            	        }
	            	        
	            	        System.out.println("\n1.Add More Product"
	            	        		+"\n2.Submit receipt\n");
	            	        System.out.print("Enter a Number: ");
	            	        userInput = sc.nextInt();
	            	       // switch for check add more product or not
	            	         switch(userInput) {
	            	         	case 1:
	            	         		check=true;
	            	         		break;
	            	         	case 2:
	            	         		check=false;
	            	         		dbManager.insertIntoDatabase(dao);
	            	         		break;
	            	         	default:
	            	         		check=false;
	            	         		System.out.println("You Entered Wrong Number");
	            	         		break;
	            	         }	            			
	        		    }
            			System.out.println("Press Enter for Main Page");
            			sc.nextLine();
	            		databaseConnected=true;
	            		break;	
	            		
	            	case 3:
	            		dbManager.viewReceiptList(20, 0);
	            		System.out.println("Enter ReceiptId for Update: ");
	            		sc.nextLine();
	        		    String updateReceiptID = sc.nextLine().trim();
	        		    boolean updating=true;
	        		    while(updating) {
	        		    	System.out.println("Enter 1 for update Receipt Date and Vendor"
	        		    				   + "\nEnter 2 for update line items"
	        		    				   + "\nEnter 3 for insert new line item"
	        		    				   + "\nEnter 4 for close update");
	        		    	System.out.print("Enter a number: ");
	        		    	userInput = sc.nextInt();
	        		    	switch(userInput) {
	        		    		case 1:
	        		    			System.out.println("Enter 1 for update Date: "
	        		    					       + "\nEnter 2 for update Vendor: "
	        		    					       + "\nEnter 3 for update both: ");
	        		    			System.out.print("Enter a number: ");
	        		    			userInput=sc.nextInt();
	        		    			switch(userInput) {
	        		    				case 1:
	        		    					System.out.print("Enter Date (dd-MM-yyyy): ");
	        		    					String updateDate=sc.next();
	        		    					if(!isDateValid(updateDate)) {databaseConnected = true;break;}
	        		    					dbManager.updateReceiptDate(updateReceiptID, updateDate);
	        		    					break;
	        		    				case 2:
	        		    					System.out.print("Enter a vendorID: ");
	        		    					String updateVendorID=sc.next();
	        		    					dbManager.updateVendorID(updateReceiptID, updateVendorID);
	        		    					break;
	        		    				case 3:
	        		    					System.out.print("Enter Date (dd-MM-yyyy): ");
	        		    				    updateDate=sc.next();
	        		    				    if(!isDateValid(updateDate)) {databaseConnected = true;break;}
	        		    				    dbManager.updateReceiptDate(updateReceiptID, updateDate);
	        		    					System.out.print("Enter a vendorID: ");
	        		    					updateVendorID=sc.next();
	        		    					dbManager.updateVendorID(updateReceiptID, updateVendorID);
	        		    					break;
	        		    				default:
	        		    					System.out.println("Invalid Input");
	        		    					break;
	        		    			}
	        		    			break;
	        		    			
	        		    		case 2:
	        		    			dbManager.showReceipt(updateReceiptID);
	        		    			dbManager.storeLineitemPK(updateReceiptID);
	        		    			System.out.println("Enter a Line Number for update: ");
	        	        		    userInput = sc.nextInt();
	        	        		    String pk = dbManager.LineItemPrimaryKey.get(userInput-1);
	        	        		    
	        	        		    System.out.println("Enter 1 for update ProductID"
	        	        		    				+ "\nEnter 2 for update Expiry Date"
	        	        		    				+ "\nEnter 3 for update Quantity"
	        	        		    				+ "\nEnter 4 for update all Value in line");
	        	        		    System.out.print("Enter a Number: ");
	        	        		    switch(userInput = sc.nextInt()){
	        	        		    	case 1:
	        	        		    		dbManager.showProduct();
	        	        		    		System.out.print("Enter Product ID: ");
	        	        		    		dbManager.updateProductID(updateReceiptID,sc.next(),pk.toString());
	        	        		    		break;
	        	        		    	case 2:
	        	        		    		System.out.print("Enter Expiry Date (dd-MM-yyyy): ");
	        	        		    		String updateDate =sc.next();
	        	        		    		if(!isDateValid(updateDate)) {databaseConnected = true;break;}
	        	        		    		dbManager.updateExpiryDate(updateReceiptID, updateDate, pk);
	        	        		    		break;
	        	        		    	case 3:
	        	        		    		System.out.print("Enter Quantity: ");
	        	        		    		dbManager.updateQuantity(updateReceiptID, sc.next(), pk);
	        	        		    		break;
	        	        		    	case 4:
	        	        		    		dbManager.showProduct();
	        	        		    		System.out.print("Enter Product ID: ");
	        	        		    		dbManager.updateProductID(updateReceiptID,sc.next(),pk.toString());
	        	        		    		System.out.print("Enter Expiry Date (dd-MM-yyyy): ");
	        	        		    		updateDate =sc.next();
	        	        		    		if(!isDateValid(updateDate)) {databaseConnected = true;break;}
	        	        		    		dbManager.updateExpiryDate(updateReceiptID, updateDate, pk);
	        	        		    		System.out.print("Enter Quantity: ");
	        	        		    		dbManager.updateQuantity(updateReceiptID, sc.next(), pk);
	        	        		    		break;	
	        	        		    	default:
	        	        		    		System.out.println("\nInvalid input\n");
	        	        		    		break;
	        	        		    }
	        		    			break;
	        		    		case 3:
	        		    			dbManager.showProduct();
    		            			System.out.print("Enter Product ID: ");
    		            			String productId=sc.next();	            			
    		            			System.out.print("Enter Expiry Date: ");
    		            			String expiryDate=sc.next();
    		            			if(!isDateValid(expiryDate)) {databaseConnected = true;break;}
    		            			System.out.print("Enter Quanitity: ");
    		            			int quantity =sc.nextInt();
    		            			dao= new GoodsReceipt("vasanth",updateReceiptID);
    		            			dao.addLineItem(productId, dbManager.stringToLocalDate(expiryDate), quantity);
    		            			
    		            			System.out.println("\nAdded Products: ");
    		            	        for (ReceiptLineItem item : dao.getLineItems()) {
    		            	        	
    		            	        	String pid[] = dbManager.productMap.get(item.getProductId());
    		            	        	String space="";
    		                            if(pid[0].length() < 11) {
    		                            	for (int i=0;i<(11-pid[0].length());i++) {
    		                            		space +=" ";
    		                            	}
    		                            }
    		            	            System.out.println(pid[0] +space+" "+ item.getDate()+" "+ item.getQuantity());
    		            	        }
    		            	        
    		            	        System.out.println("\n1.Add More Product"
    		            	        		+"\n2.Submit receipt\n");
    		            	        System.out.print("Enter a Number: ");
    		            	        userInput = sc.nextInt();
    		            	        //switch for check add more product or not
    		            	        switch(userInput) {
    	            	         		case 1:
    	            	         			check=true;
    	            	         			break;
    	            	         		case 2:
    	            	         			check=false;
    	            	         			dbManager.updateIntoDatabase(dao);
    	            	         			break;
    	            	         		default:
    	            	         			check=false;
    	            	         			System.out.println("You Entered Wrong Number");
    	            	         			break;
    	            	             	}
    	        		    			break;
	        		    		case 4:
	        		    			updating=false;
	        	        		    databaseConnected=true;
	        	        		    System.out.println("Updating closed\n");
	        		    			break;
	        		    		default:
	        		    			System.out.println("Enter Valid Input");
	        		    	        break;
	        		    	}    	
	        		    }  		    
	            		break;
	            	case 4:
	            		System.out.println("Enter 1 for delete Receipt"
	            					   + "\nEnter 2 for delete lineitems of Receipt");
	            		System.out.print("Enter a number: ");
	            		switch(sc.nextInt()) {
	            			case 1:
	            				dbManager.viewReceiptList(20, 0);
	            				System.out.print("Enter ReceiptID for delete: ");
	            				dbManager.deleteReceipt(sc.next());
	            				break;
	            			case 2:
	            				dbManager.viewReceiptList(20, 0);
                                System.out.print("Enter ReceiptID for view Lineitem: ");
                                receiptId=sc.next();
                                dbManager.showReceipt(receiptId);
                                dbManager.storeLineitemPK(receiptId);
                                System.out.print("Enter lineNumber for delete: ");
                                String pk = dbManager.LineItemPrimaryKey.get((sc.nextInt())-1);
                                dbManager.deleteLineItem(pk);
	            				break;
	            			default:
	            				System.out.println("Enter valid Input");
	            		}
	            		databaseConnected=true;
	            		break;
	            	case 5:
	            		dbManager.viewProductStock();
	            		databaseConnected=true;
	            		break;
	            	case 6:
	            		dbManager.viewReceiptList(20, 0);
	        		    System.out.print("Enter a Receipt No: ");
	            		dbManager.viewReceiptByDao(sc.next());
	            		databaseConnected=true;
	            		sc.nextLine();
	            		System.out.println("\nPress Enter for Main Page");
	        		    sc.nextLine();
	            		break;
	            	case 7:
	            		databaseConnected=false;
	            		System.out.println("connection Closed");
	            		break;
	            	default:
	            		System.out.println("Enter valid number");
	            		databaseConnected=true;
	            		break;
	        	}
	        }	
		    }catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            sc.close();
	        }
	}
}
