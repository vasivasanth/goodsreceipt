package com.qualian.testing;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/example")
public class Hello extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private  final String URL = "jdbc:postgresql://localhost:5432/erp";
    private  final String USER = "postgres";
    private  final String PASSWORD = "";
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");  
        PrintWriter out = response.getWriter();  
              
        String name=request.getParameter("Name");  
        String password=request.getParameter("Password");  
              
        if(password.equals("12345")){  
        	
        	//name = java.net.URLEncoder.encode(name, "UTF-8");
            //password = java.net.URLEncoder.encode(password, "UTF-8");
            response.sendRedirect("Welcome.html?Name=" + name + "&Password=" + password);
            
        }  
        else{  
            out.print("Sorry username or password error");  
            RequestDispatcher rd=request.getRequestDispatcher("LoginPage.html");  
            rd.include(request,response);  
        }  
              
        out.close();  
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
        try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
          String sql = "select vendor.name, * from m_inout join vendor on m_inout.vendor_id = vendor.vendor_id";
		       try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
		    		 PreparedStatement stmt = connection.prepareStatement(sql);
		             ResultSet rs = stmt.executeQuery()) {
		            
		    	    out.println("<html><head><title>Product Table</title><link rel=\"stylesheet\" href=\"Style.css\"><script src=\"https://kit.fontawesome.com/1026cb4533.js\" crossorigin=\"anonymous\"></script></head><body>");
		            out.println("<h1>Goods Receipts</h1>  <table border=\"1\">");
		            out.println("<thead><tr class=\"tableHeader\">\n"
		            		+ "<th id=\"th1\">S No</th>\n"
		            		+ "<th id=\"th2\">Receipt Id</th>\n"
		            		+ "<th id=\"th3\">Receipt Date</th>\n"
		            		+ "<th id=\"th4\">Vendor</th>\n"
		            		+ "<th id=\"th5\">Action</th>\n"
		            		+ "</tr> </thead> <tbody>");
		            int c=0;
		            while (rs.next()) {
		            
		                out.println("<tr> <td>"+(++c)+"</td>"
		                		    + "<td>"+rs.getString("document_id")+"</td>"
		                            + "<td>"+rs.getString("document_date")+"</td>"
		                            + "<td>"+rs.getString(1)+"</td>"
		                            + "<td class=\"action\">"
		                            + "<i title=\"view\" class=\"fa-solid fa-eye\"></i>"
		                            + "<i title=\"edit\" class=\"fa-solid fa-pen-to-square\"></i>"
		                            + "<i title=\"delete\" class=\"fa-solid fa-trash\"></i>"
		                            + "</td></tr>"); 
		            }
		            out.println("</tbody></table>");
		            out.println("</body></html>");
		        }
		      catch (SQLException e) {
		         e.printStackTrace();
		      }
		    }
		
	}


