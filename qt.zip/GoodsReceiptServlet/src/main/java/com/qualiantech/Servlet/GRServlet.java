package com.qualiantech.Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qualiantech.GoodsReceiptDAO.ReceiptDAO;
import com.qualiantech.GoodsReceiptDAO.ReceiptLineItemVO;
import com.qualiantech.GoodsReceiptDAO.ReceiptVO;

@WebServlet("/GRServlet")
public class GRServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public GRServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 		
		String pageParam = request.getParameter("page");
		String loadProductParam = request.getParameter("loadProduct");
		String loadVendorParam = request.getParameter("loadVendor");
        String updateReceiptID = request.getParameter("receiptID");
		if (pageParam != null) {
		    try {
		        int page = Integer.parseInt(pageParam);
		        loadReceiptTable(page, response);
		    } catch (NumberFormatException e) {
		        loadReceiptTable(1, response); // Default to page 1 if parsing fails
		    }
		} else if ("true".equals(loadProductParam)) {
		    loadProduct(response);
		} else if ("true".equals(loadVendorParam)) {
		    loadVendor(response);
		} else if(updateReceiptID != null){
			viewLineItem(updateReceiptID,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lineItemParam =request.getParameter("receiptID");
		String receiptData = request.getParameter("receiptData");
		if (lineItemParam != null) {
			viewLineItem(lineItemParam,response);
		}
		else if( receiptData !=null) {
			try {
				JSONObject jsonObject = new JSONObject(receiptData);
				storeReceiptData(jsonObject,response);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void loadReceiptTable(int page, HttpServletResponse response) {
		response.setContentType("application/json");
        int recordsPerPage = 5;        
        int start = (page - 1) * recordsPerPage;
        try {
            ReceiptDAO receiptDao = new ReceiptDAO();
            int totalRecords = receiptDao.receiptCount();
            int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);
            ArrayList<ReceiptVO> receiptVO = receiptDao.receiptVO(recordsPerPage, start);

            JSONArray jsonArray = new JSONArray();
            int c=1;
            for (ReceiptVO rv : receiptVO) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("sno", c++); 
                jsonObject.put("receiptId", rv.getReceiptId());
                jsonObject.put("receiptDate", rv.getReceiptDate().toString()); 
                jsonObject.put("vendorId", rv.getVendorId());
                jsonArray.put(jsonObject);
            }

            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("receipts", jsonArray);
            jsonResponse.put("currentPage", page);
            jsonResponse.put("totalPages", totalPages);

            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	public void viewLineItem(String receiptID, HttpServletResponse response) throws IOException {
		response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        ReceiptDAO receiptDao = new ReceiptDAO();
        JSONArray jsonArray = new JSONArray();
        if (receiptID != null && !receiptID.isEmpty()) {
            ArrayList<ReceiptLineItemVO> receiptLineItems = receiptDao.receiptLineItemVO(receiptID);
            try {
                for (ReceiptLineItemVO item : receiptLineItems) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("productId", item.getProductId());
                    if(item.getDate() != null) {
                    	jsonObject.put("date", item.getDate());
                    }
                    else {
                    	jsonObject.put("date", "");
                    }
                    jsonObject.put("quantity", item.getQuantity());
                    jsonArray.put(jsonObject);
                }
                }catch(Exception e){
                	e.printStackTrace();
                } 
                out.println(jsonArray.toString());
                out.flush();
             }
        else {
        	out.println("[]");
        }
	}
	
	
	public void loadProduct(HttpServletResponse response) {
		response.setContentType("application/json");
		try {
			ReceiptDAO receiptDao = new ReceiptDAO();
			receiptDao.storeProductInMap(); 
			JSONArray jsonArray = new JSONArray();
			for (Map.Entry<String, String[]> entry : receiptDao.productMap.entrySet()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("productID",entry.getKey());
				String[] productDetail = entry.getValue();
					jsonObject.put("productName", productDetail[0]);
					jsonObject.put("productUom", productDetail[1]);
					jsonArray.put(jsonObject);
				}
			PrintWriter out = response.getWriter();
			out.print(jsonArray.toString());
			out.flush();
		} catch (Exception e) {
		  e.printStackTrace();
        }
			
	 }
	
	public void loadVendor(HttpServletResponse response) {
		response.setContentType("application/json");
		try {
			ReceiptDAO receiptDao = new ReceiptDAO();
			receiptDao.storeVendorInMap(); 
			JSONArray jsonArray = new JSONArray();
			for (Map.Entry<String, String> entry : receiptDao.vendorMap.entrySet()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("vendorID",entry.getKey());
		        jsonObject.put("vendorName", entry.getValue());
				jsonArray.put(jsonObject);
		    }
			PrintWriter out = response.getWriter();
			out.print(jsonArray.toString());
			out.flush();
        }catch (Exception e) {
  		  e.printStackTrace();		
	   }
    }
	
	
	public void storeReceiptData(JSONObject jsonObject, HttpServletResponse response) throws JSONException, IOException {
		response.setContentType("application/json");
		ReceiptDAO rDao = new ReceiptDAO();
		ReceiptVO rv=rDao.setReceiptData(jsonObject);
		rDao.insertIntoDatabase(rv);
		PrintWriter out = response.getWriter();
		JSONObject jsonResponse = new JSONObject();
 	    jsonResponse.put("success", true);
 	    out.print(jsonResponse.toString());
 	    out.flush();
		
    }
	
}
