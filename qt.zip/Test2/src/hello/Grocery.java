package hello;
import java.util.Scanner;
class Grocery{
  public static void main(String[] args){
   Scanner sc = new Scanner(System.in);
   String[] productList={"101-Mango", "102-Apple", "103-Orange", "104-Papaya", "105-Carrot"};
   int[] productPrice={125,345,122,105,150}; 
   System.out.println("  GROCERY SHOP   ");
   int totalAmount=0;
  
  //Print Product Details 	  
   for(int i=0; i<productList.length; i++){
   	   String space="";
   	   if(productList[i].length()<10){
   	   	for(int j=0; j<(10-productList[i].length()); j++){
   	   	     space+=" ";
   	   	}
   	   }
   	   System.out.println(productList[i]+space+" "+productPrice[i]+" ₹ Per Kg" );		
   }
   int userInput=0;
   boolean breakPoint=true;;
  
   while(breakPoint){
       System.out.println("Enter 1 for Add Product"
                      +"\nEnter 2 for Exist");
       System.out.print("Enter a Number: ");
  	userInput = sc.nextInt();
  	switch(userInput){
  	   case 1:
  	          boolean addProduct=true;
  	          while(addProduct){        
  	             System.out.print("Enter Product ID: ");
  	             userInput = sc.nextInt();
  	             
  	             int len=productList[userInput-101].length();
  	             String selectedProduct = productList[userInput-101].substring(4,len);
  	             int selectedProductPrice = productPrice[userInput-101];
  	  
  	             System.out.print("Enter quantity of Product: ");
                    userInput = sc.nextInt();
                    totalAmount += userInput*selectedProductPrice;
                    System.out.println(userInput+" Quantity of "+selectedProduct
                                       +" price is "+(userInput*selectedProductPrice)); 
                    
                    System.out.println();
                    while(true){
                       System.out.println("Enter 1 for Add More Product"
                                        +"\nEnter 2 for Bill");
                       System.out.print("Enter a Number: ");
                       userInput=sc.nextInt();
                       if(userInput == 1){
                           break;
                       }
                       else if(userInput == 2){ 
                          System.out.println("Total Amount is : "+totalAmount);
                          addProduct=false; 
                          breakPoint=false;
                          break; 
                       }
                       else{ 
                           System.out.println("Enter valid Input");
                       }
                    }                                   
  	          }
  	          break;
  	   case 2:
  	          breakPoint=false;
  	          break;  	   
  	   default:
  	       System.out.println("Enter valid Input");
  	       break;
  	   }   
    }

   }
}