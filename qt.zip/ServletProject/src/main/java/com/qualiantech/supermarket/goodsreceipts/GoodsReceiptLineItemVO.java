package com.qualiantech.supermarket.goodsreceipts;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class GoodsReceiptLineItemVO {
	private String inoutlineId;
	private char isActive;
    private LocalDateTime createdTime;
	private String createdBy;
	private LocalDateTime updatedTime;
	private String updatedBy;
	private String receiptId;
	private String productId;
	private LocalDate expiryDate;
    private int quantity;
	
      //Setter
	  public void setInoutlineId(String inoutlineId) {
		  this.inoutlineId = inoutlineId;
	    }
	  
	  public void setIsActive(char isActive) {
		  this.isActive=isActive;
	    }
	  
	  public void setCreatedTime(LocalDateTime createdTime) {
		  this.createdTime=createdTime;
	    }
	  
	  public void setCreatedBy(String createdBy) {
		  this.createdBy=createdBy;
		}
	  
	  public void setUpadtedTime(LocalDateTime updatedTime) {
		  this.updatedTime=updatedTime;
		}
	  
	  public void setUpdatedBy(String updatedBy) {
		  this.updatedBy=updatedBy;
		}
	  
	  public void setReceiptId(String receiptId) {
		  this.receiptId=receiptId;
		}
	  
	  public void setProductId(String productId) {
		  this.productId=productId;
		}
	  
	  public void setExpiryDate(LocalDate date) {
		  this.expiryDate=date;
		}
	  
	  public void setQuantity(int quantity) {
		  this.quantity=quantity;
		}
	  
	  
	  //Getter
	  public String getInoutlineId() {
		  return inoutlineId;
		}
	  
	  public char getIsActive() {
		  return isActive;
		}
	  
	  public LocalDateTime getCreatedTime() {
		  return createdTime;
		}
	  
	  public String getCreatedBy() {
		  return createdBy;
		}
	  
	  public LocalDateTime getUpdatedTime() {
		  return updatedTime;
		}
	  
	  public String getUpdatedBy() {
		  return updatedBy;
		}
	  
	  public String getReceiptId() {
		  return receiptId;
		}
	  
	  public String getProductId() {
		  return productId;
		}
	  
	  public LocalDate getExpiryDate() {
		  return expiryDate;
		};
		
	  public int getQuantity() {
		  return quantity;
		};
		
}
