package com.qualiantech.supermarket.goodsreceipts;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

//import java.util.ArrayList;

public class GoodsReceiptVO {
	private String inoutId;
    private char isActive;
    private LocalDateTime createdTime;
	private String createdBy;
	private LocalDateTime updatedTime;
	private String updatedBy;
	private String vendorId;
	private String receiptId;
	private LocalDate receiptDate;
	private List<GoodsReceiptLineItemVO> goodsReceiptLineItem;

	//Setter
	public void setInoutId(String inoutId) {
		this.inoutId = inoutId;
	 }
	
	public void setIsActive(char isActive) {
		this.isActive=isActive;
	 }
	
	public void setCreatedTime(LocalDateTime created) {
		this.createdTime=created;
	 }
	
	public void setCreatedBy(String createdBy) {
		this.createdBy=createdBy;
	 }
	
	public void setUpadtedTime(LocalDateTime updated) {
		this.updatedTime=updated;
	 }
	
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy=updatedBy;
	 }
	
	public void setVendorId(String vendorId) {
		this.vendorId=vendorId;
	 }
	
	public void setReceiptId(String receiptId) {
		this.receiptId=receiptId;
	 }
	
	public void setReceiptDate(LocalDate date) {
		this.receiptDate=date;
	 }
	
	public void setGoodsReceiptLineItem(List<GoodsReceiptLineItemVO> goodsReceiptLineItem) {
		this.goodsReceiptLineItem = goodsReceiptLineItem;
	}

	
	//Getter 
	public String getInoutId() {
		return inoutId;
	 }
	
	public char getIsActive() {
		return isActive;
	 }
	
	public LocalDateTime getCreatedTime() {
		return createdTime;
	 }
	
	public String getCreatedBy() {
		return createdBy;
	 }
	
	public LocalDateTime getUpdatedTime() {
		return updatedTime;
	 }
	
	public String getUpdatedBy() {
		return updatedBy;
	 }
	
	public String getReceiptId() {
		return receiptId;
	 }
	
	public LocalDate getReceiptDate() {
		return receiptDate;
	 }
	
	public String getVendorId() {
		return vendorId;
	 }
	
	public List<GoodsReceiptLineItemVO> getGoodsReceiptLineItem(){
		return goodsReceiptLineItem;
	 }
}

