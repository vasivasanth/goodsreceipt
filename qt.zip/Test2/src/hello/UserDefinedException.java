package hello;

public class UserDefinedException extends Exception{

	public UserDefinedException(String msg) {
		super(msg);
	}
}
