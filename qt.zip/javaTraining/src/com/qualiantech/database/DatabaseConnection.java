package com.qualiantech.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	private static final String URL = "jdbc:postgresql://localhost:5432/erp";
    private static final String USER = "postgres";
    private static final String PASSWORD = "";

    private Connection connection;

    public DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to database.");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to connect to database.");
        }
    }
    public Connection getConnection() {
        return connection;
    }	 
}

/*

1. Create 3 java files
	- DB connection
	- DAO 
	- Main
	 
2. DB connection - connection to DB alone (Static or non static)

3. DAO class (Encapsulation) getter setter

4. Main class 
		- Establish connection to database
		- Show options to the user - view, insert, update
		- Get input from the user
		- Based on the input perform the actions 
	if view
		- get number of rows to view
			for example :5   5 rows will be displayed
		- with OFFSET : 5 limit 10  
			example limit: 10 offset: 5    
				10 rows will be displayed from 5 to 15			
	if insert or update
		- Store it in collection
		- setAutoCommit(false)
		- After finished getting input from the user Insert into DB
		- If successful show a successful message. If not show an error message.

		// use  Prepared Statement() for insert, update

	JAVA Date
	Naming convention
	Indentation
 */

/* public void closeConnection() {
if (connection != null) {
    try {
        connection.close();
        System.out.println("Connection closed.");
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
} */
