package com.qualiantech.GoodsReceiptDAO;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ReceiptDAO {
	private static final String URL = "jdbc:postgresql://localhost:5432/erp";
    private static final String USER = "postgres";
    private static final String PASSWORD = "";
    private static Connection connection=null;
    
    //open connection
    public static boolean openConnection() {
    	try {
    		if(connection == null || connection.isClosed()) {
    			Class.forName("org.postgresql.Driver");
    		   connection = DriverManager.getConnection(URL, USER, PASSWORD);
    		}
    		return true;
    	}
    	catch(Exception e) {
            e.printStackTrace();
            return false;
    	}

     }
    
    //close connection
    public static boolean closeConnection() {
    	try {
    		if(connection != null || !connection.isClosed()) {
    			connection.close();
    		}
    		return true;
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	    return false;	
    	}
    }
    
    //set data to receiptVO
	public ArrayList<ReceiptVO> receiptVO(int limit, int offset){ 	
	    if (!openConnection()) {
	       throw new RuntimeException("Failed to open database connection.");
	     }
	    ArrayList<ReceiptVO> receiptVO = new   ArrayList<ReceiptVO>();
	    String sql = "select vendor.name, * from m_inout join vendor on m_inout.vendor_id = vendor.vendor_id limit ? offset ?";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);){
    		 stmt.setInt(1, limit);
			 stmt.setInt(2, offset);
			 ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	            	ReceiptVO r=new ReceiptVO();
	            	r.setVendorId(rs.getString(1));
	            	r.setReceiptId(rs.getString("document_id"));
	            	r.setDate(rs.getDate("document_Date").toLocalDate());
	            	receiptVO.add(r);
	            }
	            return receiptVO;
    	}catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    	return null;              
 }
	
	//Receipts count
    public int receiptCount() throws SQLException {
    	 if (!openConnection()) {
  	       throw new RuntimeException("Failed to open database connection.");
  	     }
    	 String sql="select count(*) from m_inout";
    	 try(Statement stmt = connection.createStatement()){ 
    		 ResultSet rs = stmt.executeQuery(sql);
    		 rs.next();
    		 return rs.getInt(1);
    	 }
    	 catch(SQLException e) {
    		 e.printStackTrace();
    	 }
    	 finally {
    		 closeConnection();
    	   }
       return 0;
    } 
	
   //receiptLineitemVO
    public ArrayList<ReceiptLineItemVO> receiptLineItemVO(String receiptID){ 	
	    if (!openConnection()) {
	       throw new RuntimeException("Failed to open database connection.");
	     }
	    ArrayList<ReceiptLineItemVO> receiptLineItemVO = new   ArrayList<ReceiptLineItemVO>();
	    String sql = "select product.name,expiry_date,quantity from m_inoutline "
	    		      + "join product on m_inoutline.product_id=product.product_id "
	    		      + "join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id "
	    		      + "where m_inout.document_id=?";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);){
    		 stmt.setString(1, receiptID);
			 ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	            	ReceiptLineItemVO r=new ReceiptLineItemVO();
	            	r.setProductId(rs.getString(1));
	            	r.setDate(rs.getDate(2).toLocalDate());
	            	r.setQuantity(rs.getInt(3));;
	            	receiptLineItemVO.add(r);
	            }
	            return receiptLineItemVO;
    	}catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    	return null;              
 } 
    
}
