package com.qualiantech.GoodsReceiptDAO;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ReceiptVO {
	private String inoutId;
    private char isactive;
    private LocalDateTime created;
	private String createdby;
	private LocalDateTime updated;
	private String updatedby;
	private String vendorId;
	private String receiptId;
	private LocalDate receiptDate;
	private List<ReceiptLineItemVO> lineItems;
	//constructor
	public ReceiptVO() {}
	public ReceiptVO(String name,String receiptId) {
		this.createdby=name;
		this.updatedby=name;
		this.receiptId=receiptId;
		this.lineItems = new ArrayList<>();
	}
	
	//Setter
	public void setInoutId(String inoutId) {this.inoutId = inoutId;}
	public void setIsactive(char isactive) {this.isactive=isactive;}
	public void setCreated(LocalDateTime created) {this.created=created;}
	public void setCreatedby(String createdby) {this.createdby=createdby;}
	public void setUpadted(LocalDateTime updated) {this.updated=updated;}
	public void setUpdatedby(String updatedby) {this.updatedby=updatedby;}
	public void setVendorId(String vendorId) { this.vendorId=vendorId;}
	public void setReceiptId(String receiptId) {this.receiptId=receiptId;}
	public void setDate(LocalDate date) { this.receiptDate=date;}
	public void setLineItems(List<ReceiptLineItemVO> lineItems) {
		this.lineItems = lineItems;
	}

	public void addLineItem(String productId, LocalDate date, int quantity) {
		ReceiptLineItemVO item = new ReceiptLineItemVO(productId, date, quantity);
        lineItems.add(item);
    } 
	
	//Getter 
	public String getInoutId() {return inoutId;}
	public char getIsactive() {return isactive;}
	public LocalDateTime getCreated() {return created;}
	public String getCreatedby() {return createdby;}
	public LocalDateTime getUpdated() {return updated;}
	public String getUpdatedby() {return updatedby;}
	public String getReceiptId() {return receiptId;}
	public LocalDate getReceiptDate() {return receiptDate;}
	public String getVendorId() {return vendorId;}
	public List<ReceiptLineItemVO> getLineItems(){return lineItems;}
}
