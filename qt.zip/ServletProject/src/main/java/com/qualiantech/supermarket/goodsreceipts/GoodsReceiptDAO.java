package com.qualiantech.supermarket.goodsreceipts;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoodsReceiptDAO {
	private final String URL = "jdbc:postgresql://localhost:5432/erp";
    private final String USER = "postgres";
    private final String PASSWORD = "";
    private Connection connection=null;
    public String userName="vasanth";

    //open connection
    public boolean openConnection() {
    	try {
    		if(connection == null || connection.isClosed()) {
    			Class.forName("org.postgresql.Driver");
    		   connection = DriverManager.getConnection(URL, USER, PASSWORD);
    		}
    		return true;
    	}
    	catch(Exception e) {
            e.printStackTrace();
            return false;
    	}
     }

    //close connection
    public boolean closeConnection() {
    	try {
    		if(connection != null || !connection.isClosed()) {
    			connection.close();
    		}
    		return true;
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	    return false;	
    	}
    }
       
  //Get full receipt value
    public ArrayList<GoodsReceiptVO> getGoodsReceipts(int limit, int offset){
    	if (!openConnection()) {
 	       throw new RuntimeException("Failed to open database connection.");
 	     }
 	    ArrayList<GoodsReceiptVO> GoodsreceiptsArray = new   ArrayList<GoodsReceiptVO>();
 	    String receiptHeaderQuery = "select vendor.name, * from m_inout join vendor on m_inout.vendor_id = vendor.vendor_id order by m_inout.updated desc limit ? offset ?";
 	    String receiptLineItemQuery = "select product.name,expiry_date,quantity from m_inoutline "
 	    		   					+ "join product on m_inoutline.product_id=product.product_id "
 	    		   					+ "join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id "
 	    		   					+ "where m_inout.document_id=?";
 	    try{
     		 PreparedStatement receiptHeaderStmt = connection.prepareStatement(receiptHeaderQuery);
     		 receiptHeaderStmt.setInt(1, limit);
     		 receiptHeaderStmt.setInt(2, offset);
 			 ResultSet rs = receiptHeaderStmt.executeQuery();
 	            while (rs.next()) {
 	            	GoodsReceiptVO receiptVO = new GoodsReceiptVO();
 	            	receiptVO.setVendorId(rs.getString(1));
 	            	receiptVO.setReceiptId(rs.getString("document_id"));
 	            	receiptVO.setReceiptDate(rs.getDate("document_Date").toLocalDate());
                    
 	            	ArrayList<GoodsReceiptLineItemVO> GoodsreceiptLineItemArray = new ArrayList<GoodsReceiptLineItemVO>();
 	            	
 	            	PreparedStatement LineItemStmt = connection.prepareStatement(receiptLineItemQuery);
 	            	LineItemStmt.setString(1, rs.getString("document_id"));
 	            	ResultSet rsLineItem = LineItemStmt.executeQuery();
    		
 	            	while (rsLineItem.next()) {
 	            			GoodsReceiptLineItemVO LineItemVO=new GoodsReceiptLineItemVO();
 	            			LineItemVO.setProductId(rsLineItem.getString(1));
 	            				if (rsLineItem.getDate(2) != null) {
 	            					LineItemVO.setExpiryDate(rsLineItem.getDate(2).toLocalDate());
 	            				} else {
 	            					LineItemVO.setExpiryDate(null);
 	            				}
 	            			LineItemVO.setQuantity(rsLineItem.getInt(3));;
 	            			GoodsreceiptLineItemArray.add(LineItemVO);
 	            		}
 	            	receiptVO.setGoodsReceiptLineItem(GoodsreceiptLineItemArray);
 	            	GoodsreceiptsArray.add(receiptVO);
 	            }
 	            return GoodsreceiptsArray;
     	}catch (SQLException e) {
             e.printStackTrace();
         } finally {
             closeConnection();
         }
     	return null; 
    }

 //Receipts count for pagination
    public ArrayList<String> getAllGoodsReceiptsId() throws SQLException {
    	 if (!openConnection()) {
  	       throw new RuntimeException("Failed to open database connection.");
  	     }
    	 String query ="select document_id from m_inout";
    	 ArrayList<String> receiptsId = new ArrayList<String>();
    	 try{
    		  Statement stmt = connection.createStatement();
    		  ResultSet rs = stmt.executeQuery(query);
    		  while(rs.next()) {
    			  receiptsId.add(rs.getString(1));
    		 }
    		  return receiptsId;
    	 }
    	 catch(SQLException e) {
    		 e.printStackTrace();
    	 }
    	 finally {
    		 closeConnection();
    	   }
       return null;
    } 
	 
    public boolean deleteGoodsReceipt(String deleteReceiptId) throws SQLException {
    	 if (!openConnection()) {
  	       throw new RuntimeException("Failed to open database connection.");
  	     }
    	  String query="delete from m_inout where document_id = ?";
    	  try{
    		  PreparedStatement deleteStmt = connection.prepareStatement(query);
    		  deleteStmt.setString(1, deleteReceiptId);
    		  int check=deleteStmt.executeUpdate();
    		  return check>0;
    	  } catch(Exception e) {
    		  e.printStackTrace();
    		  return false;
    	  }finally {
    		  closeConnection();
    	  }
    }
    
    
    public Map<String, String[]> products = new LinkedHashMap<>();
    public void getProducts() {
       if (!openConnection()) {
   	       throw new RuntimeException("Failed to open database connection.");
   	   }
       String query = "select code, name, uom from product order by code asc";
       try {
    	    PreparedStatement stmt = connection.prepareStatement(query);
            ResultSet rs = stmt.executeQuery(); 
            while (rs.next()) {
            	String a[]=new String[2];
                String productId = rs.getString(1);
                a[0]=rs.getString(2);
                a[1]=rs.getString(3);
                products.put(productId, a);
            }
        }
      catch (SQLException e) {
         e.printStackTrace();
      }finally {
		  closeConnection();
	  }
    }
    
  
    public  Map<String, String> vendors = new LinkedHashMap<>();    
    public void getVendors() {
    	if (!openConnection()) {
    	       throw new RuntimeException("Failed to open database connection.");
    	   }
    	String query = "select code, name from vendor";
    	try(PreparedStatement stmt = connection.prepareStatement(query);
    		ResultSet rs=stmt.executeQuery() ){
    		while(rs.next()) {
    			String vendorId = rs.getString(1);
    			String vendorName = rs.getString(2);
    			vendors.put(vendorId, vendorName);
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
  		  closeConnection();
  	  }	
    }
    
    
  //set the receipt data into VO
    
    public GoodsReceiptVO setGoodsReceiptVO(JSONObject jsonObject) throws JSONException {       
        GoodsReceiptVO receiptVO = new GoodsReceiptVO();
        receiptVO.setCreatedBy(userName);
        receiptVO.setUpdatedBy(userName);
        receiptVO.setReceiptId(jsonObject.getString("receiptID"));
        receiptVO.setVendorId(jsonObject.getString("selectedVendor").split(" ")[0]);
        receiptVO.setReceiptDate(LocalDate.parse(jsonObject.getString("receiptDate")));
 
        JSONArray products = jsonObject.getJSONArray("products");
        List<GoodsReceiptLineItemVO> lineItems = new ArrayList<>();
        for (int i = 0; i < products.length(); i++) {
            JSONObject product = products.getJSONObject(i);
            GoodsReceiptLineItemVO rl = new GoodsReceiptLineItemVO();
            	rl.setCreatedBy(userName);
            	rl.setUpdatedBy(userName);
            	rl.setProductId(product.getString("productName").split(" ")[0]);
            String expiryDateStr = product.getString("expiryDate").trim();
            	if (!expiryDateStr.isEmpty()) {
            		rl.setExpiryDate(LocalDate.parse(expiryDateStr));
            	} else {
            		rl.setExpiryDate(null);
            	}
            	rl.setQuantity(Integer.parseInt(product.getString("quantity")));
            lineItems.add(rl);
        }
        receiptVO.setGoodsReceiptLineItem(lineItems);
        return receiptVO;   
    }
    
 
    public void insertGoodsReceipt(GoodsReceiptVO receipt) {
    	String insertReceiptQuery="insert into m_inout (createdby, updatedby, document_id, document_date, vendor_id)\n"
    		            	  + "values(?,?,?,?,(select vendor_id from vendor where code = ? ))";    	
    	
    	String insertLineItemQuery="insert into m_inoutline (createdby, updatedby, m_inout_id, product_id, expiry_date, quantity)\n"
    			               + "values(?, ?, (select m_inout_id from m_inout where document_id = ?), (select product_id from product where code=?), ?, ?)";
    	if (!openConnection()) {
 	       throw new RuntimeException("Failed to open database connection.");
 	    }
    	try { 
    		PreparedStatement receiptStmt = connection.prepareStatement(insertReceiptQuery);
    		PreparedStatement lineItemStmt = connection.prepareStatement(insertLineItemQuery);

    		connection.setAutoCommit(false);
    		Date sqlDate = Date.valueOf(receipt.getReceiptDate());

    		// Insert DAO information into m_inout table
    		receiptStmt.setString(1, userName);
    		receiptStmt.setString(2, userName);
    		receiptStmt.setString(3, receipt.getReceiptId());
    		receiptStmt.setDate(4, sqlDate);
    		receiptStmt.setString(5, receipt.getVendorId());
    		receiptStmt.executeUpdate(); 

    		// Insert line items into m_inoutline table
    		for (GoodsReceiptLineItemVO LineItem : receipt.getGoodsReceiptLineItem()) {
    			Date expiryDate = (LineItem.getExpiryDate() != null) ? Date.valueOf(LineItem.getExpiryDate()) : null;
    			lineItemStmt.setString(1, userName);
    			lineItemStmt.setString(2, userName);
    			lineItemStmt.setString(3, receipt.getReceiptId());
    			lineItemStmt.setString(4, LineItem.getProductId());    
    			lineItemStmt.setDate(5, expiryDate);
    			lineItemStmt.setInt(6, LineItem.getQuantity());
    			lineItemStmt.addBatch(); 
    		}
    		lineItemStmt.executeBatch();
    		connection.commit();

    	} catch (SQLException e) {
    		e.printStackTrace();
    		try {connection.rollback();}
    		catch (SQLException rollbackException) {
    			rollbackException.printStackTrace();
    		}
    	}
    	finally {
    		try {
    			connection.setAutoCommit(true);
    			closeConnection();
    		} catch (SQLException e) {
    			e.printStackTrace();
    		}
    	}
     }
      
    
    public void updateGoodsReceipt(GoodsReceiptVO receipt) {
    	String deleteLineItemquery="delete from m_inoutline where m_inout_id = (select m_inout_id from m_inout where document_id = ? )";
    	
    	String updateReceiptQuery="update m_inout set updated = now() at time zone 'UTC', vendor_id = (select vendor_id from vendor where code =?), document_date=? WHERE document_id=?";
    	
    	
    	String insertLineItemQuery="insert into m_inoutline (createdby, updatedby, m_inout_id, product_id, expiry_date, quantity)\n"
    			               + "values(?, ?, (select m_inout_id from m_inout where document_id = ?), (select product_id from product where code=?), ?, ?)";
    	if (!openConnection()) {
 	       throw new RuntimeException("Failed to open database connection.");
 	    }
        try { 
        	PreparedStatement deleteLineItemStmt = connection.prepareStatement(deleteLineItemquery);
            PreparedStatement receiptStmt = connection.prepareStatement(updateReceiptQuery);
            PreparedStatement lineItemStmt = connection.prepareStatement(insertLineItemQuery);
           
        	connection.setAutoCommit(false);
        	// delete line item
        	deleteLineItemStmt.setString(1, receipt.getReceiptId());
        	if(deleteLineItemStmt.executeUpdate()>0) {
        		System.out.println("line item deleted successfully");
        	}
        	      	
            Date sqlDate = Date.valueOf(receipt.getReceiptDate());
        	
            // update DAO information into m_inout table
            receiptStmt.setString(1, receipt.getVendorId());
            receiptStmt.setDate(2, sqlDate);
            receiptStmt.setString(3, receipt.getReceiptId());
            receiptStmt.executeUpdate(); 

          // Insert line items into m_inoutline table
           for (GoodsReceiptLineItemVO LineItem : receipt.getGoodsReceiptLineItem()) {
        	   Date expiryDate = (LineItem.getExpiryDate() != null) ? Date.valueOf(LineItem.getExpiryDate()) : null;
                lineItemStmt.setString(1, userName);
                lineItemStmt.setString(2, userName);
                lineItemStmt.setString(3, receipt.getReceiptId());
                lineItemStmt.setString(4, LineItem.getProductId());  
                lineItemStmt.setDate(5, expiryDate);
                lineItemStmt.setInt(6, LineItem.getQuantity());
                lineItemStmt.addBatch(); 
            }
            lineItemStmt.executeBatch();
            connection.commit();
            System.out.println("Data updated successfully."); 

        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
                closeConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
     }
    
  
    public ArrayList<GoodsReceiptVO> getGoodsReceipt(String query) throws JSONException{
    	if (!openConnection()) {
 	       throw new RuntimeException("Failed to open database connection.");
 	     }
    	
 	    String receiptHeaderQuery ="select vendor.name, * from m_inout \n"
 	    						   +"join vendor on m_inout.vendor_id = vendor.vendor_id \n"
 	    						   +"where "+query;
 	    
 	    String receiptLineItemQuery = "select product.name,expiry_date,quantity from m_inoutline "
 	    		   					+ "join product on m_inoutline.product_id=product.product_id "
 	    		   					+ "join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id "
 	    		   					+ "where m_inout.document_id=?" ;
 	    ArrayList<GoodsReceiptVO> GoodsreceiptsArray = new   ArrayList<GoodsReceiptVO>();
 	    

 	    try{
 	    	
     		 PreparedStatement receiptHeaderStmt = connection.prepareStatement(receiptHeaderQuery);
 			 ResultSet rs = receiptHeaderStmt.executeQuery();
 	            while (rs.next()) {  
 	            	GoodsReceiptVO receiptVO = new GoodsReceiptVO();
 	            	receiptVO.setVendorId(rs.getString(1));
 	            	receiptVO.setReceiptId(rs.getString("document_id"));
 	            	receiptVO.setReceiptDate(rs.getDate("document_date").toLocalDate());
                    
 	            	ArrayList<GoodsReceiptLineItemVO> receiptLineItemArray = new ArrayList<GoodsReceiptLineItemVO>();
 	            	
 	            	PreparedStatement LineItemStmt = connection.prepareStatement(receiptLineItemQuery);
 	            	LineItemStmt.setString(1, rs.getString("document_id"));
 	            	ResultSet rsLineItem = LineItemStmt.executeQuery();
    		
 	            	while (rsLineItem.next()) {
 	            			GoodsReceiptLineItemVO LineItemVO=new GoodsReceiptLineItemVO();
 	            			LineItemVO.setProductId(rsLineItem.getString(1));
 	            				if (rsLineItem.getDate(2) != null) {
 	            					LineItemVO.setExpiryDate(rsLineItem.getDate(2).toLocalDate());
 	            				} else {
 	            					LineItemVO.setExpiryDate(null);
 	            				}
 	            			LineItemVO.setQuantity(rsLineItem.getInt(3));;
 	            			receiptLineItemArray.add(LineItemVO);
 	            		}
 	            	receiptVO.setGoodsReceiptLineItem(receiptLineItemArray);
 	            	GoodsreceiptsArray.add(receiptVO);
 	            }
 	            return GoodsreceiptsArray;
     	}catch (SQLException e) {
             e.printStackTrace();
         } finally {
             closeConnection();
         }
     	return null; 
    }
    
    
  
}
