package com.qualiantech.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import com.qualiantech.GoodsReceiptDAO.*;

@WebServlet("/deleteReceiptServlet")
public class deleteReceiptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public deleteReceiptServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       ReceiptDAO dao=new ReceiptDAO();
	   response.setContentType("application/json");
       PrintWriter out = response.getWriter();
       String receiptID = request.getParameter("receiptID");
       try {
    	   boolean success = dao.deleteReceipt(receiptID);
    	   JSONObject jsonResponse = new JSONObject();
    	   jsonResponse.put("success", success);
    	   jsonResponse.put("res", receiptID);
    	   out.print(jsonResponse.toString());
    	   out.flush();
	   } catch (Exception e) {
		   e.printStackTrace();
	   }
       
	}

}
