package com.qualiantech.supermarket.goodsreceipts.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.qualiantech.supermarket.goodsreceipts.GoodsReceiptDAO;
import com.qualiantech.supermarket.goodsreceipts.GoodsReceiptVO;

@WebServlet("/GoodsReceipt")

public class GoodsReceiptServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public GoodsReceiptServlet() {
        super();
    }
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException { 		
		String pageNumber = request.getParameter("pageNumber");
		boolean isProduct = Boolean.parseBoolean(request.getParameter("getProduct"));
		boolean isVendor = Boolean.parseBoolean(request.getParameter("getVendor"));
		String searchReceiptquery = request.getParameter("query");
		if (pageNumber != null) { 
		  try{
		      int StartingPageNumber = Integer.parseInt(pageNumber);
		        sendReceiptsDataWithPagination(StartingPageNumber, response);
		    } catch (NumberFormatException e) {
		    	sendReceiptsDataWithPagination(1, response); 
		    }
		} else if (isProduct) {
			sendProductData(response);
		} else if (isVendor) {
			sendVendorData(response);
		} else if(searchReceiptquery != null) {
			sendReceiptData(searchReceiptquery, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String deleteReceiptId =request.getParameter("receiptId");
		String insertReceiptData = request.getParameter("receiptData");
		String updateReceiptData = request.getParameter("updateReceiptData");
		
		
		if (deleteReceiptId != null) {
		try {
				deleteGoodsReceipt(deleteReceiptId,response);
			} catch (IOException | SQLException | JSONException e){
				e.printStackTrace();
			}
		}
		else if(insertReceiptData !=null) {
			try {
				JSONObject jsonObject = new JSONObject(insertReceiptData);
				insertGoodsReceipt(jsonObject,response);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		else if(updateReceiptData != null) {			
			try {
				JSONObject jsonObject = new JSONObject(updateReceiptData);
				updateGoodsReceipt(jsonObject,response);
			} catch (JSONException e) {
				e.printStackTrace();
			}			
		}
		 
		
	}

	
	public void sendReceiptsDataWithPagination(int page, HttpServletResponse response) {
		response.setContentType("application/json");
        int recordsPerPage = 5;        
        int start = (page - 1) * recordsPerPage;
        GoodsReceiptDAO dao= new GoodsReceiptDAO();
        try {
        	ArrayList<String> allReceiptIdArray = dao.getAllGoodsReceiptsId();       	
            int totalRecords = allReceiptIdArray.size();
            int totalPage = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);
            ArrayList<GoodsReceiptVO> receiptsArray = dao.getGoodsReceipts(recordsPerPage, start);

            JSONArray jsonArray = new JSONArray();
            int c=1;
            for (GoodsReceiptVO receiptVo : receiptsArray) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("sno", c++); 
                jsonObject.put("receiptId", receiptVo.getReceiptId());
                jsonObject.put("receiptDate", receiptVo.getReceiptDate().toString()); 
                jsonObject.put("vendorId", receiptVo.getVendorId());
                jsonObject.put("lineItems", receiptVo.getGoodsReceiptLineItem());
                jsonArray.put(jsonObject);
            }

            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("receipts", jsonArray);
            jsonResponse.put("currentPage", page);
            jsonResponse.put("totalPage", totalPage);
            jsonResponse.put("allReceiptId", allReceiptIdArray);

            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	

	public void sendReceiptData(String searchReceiptquery, HttpServletResponse response) {
		response.setContentType("application/json");
        GoodsReceiptDAO dao= new GoodsReceiptDAO();
        try {
        	ArrayList<GoodsReceiptVO> receiptsArray = dao.getGoodsReceipt(searchReceiptquery);
            JSONArray jsonArray = new JSONArray();
            int c=1;
            for(GoodsReceiptVO receiptVO : receiptsArray) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("sno", c++); 
                jsonObject.put("receiptId", receiptVO.getReceiptId());
                jsonObject.put("receiptDate", receiptVO.getReceiptDate().toString()); 
                jsonObject.put("vendorId", receiptVO.getVendorId());
                jsonObject.put("lineItems", receiptVO.getGoodsReceiptLineItem());
                jsonArray.put(jsonObject);
            }
               
            JSONObject jsonResponse = new JSONObject();
            	jsonResponse.put("receipts", jsonArray);

            PrintWriter out = response.getWriter();
            out.print(jsonResponse.toString());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	public void sendProductData(HttpServletResponse response) {
		response.setContentType("application/json");
		GoodsReceiptDAO dao= new GoodsReceiptDAO();
		try {
			dao.getProducts(); 
			JSONArray jsonArray = new JSONArray();
			for (Map.Entry<String, String[]> entry : dao.products.entrySet()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("productID",entry.getKey());
				String[] productDetail = entry.getValue();
					jsonObject.put("productName", productDetail[0]);
					jsonObject.put("productUom", productDetail[1]);
					jsonArray.put(jsonObject);
				}
			PrintWriter out = response.getWriter();
			out.print(jsonArray.toString());
			out.flush();
		} catch (Exception e) {
		  e.printStackTrace();
        }
			
	 }
	
	
	public void sendVendorData(HttpServletResponse response) {
		response.setContentType("application/json");
		GoodsReceiptDAO dao= new GoodsReceiptDAO();
		try {
			dao.getVendors(); 
			JSONArray jsonArray = new JSONArray();
			for (Map.Entry<String, String> entry : dao.vendors.entrySet()) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("vendorID",entry.getKey());
		        jsonObject.put("vendorName", entry.getValue());
				jsonArray.put(jsonObject);
		    }
			PrintWriter out = response.getWriter();
			out.print(jsonArray.toString());
			out.flush();
        }catch (Exception e) {
  		  e.printStackTrace();		
	   }
    }
	
	
	public void insertGoodsReceipt(JSONObject jsonObject, HttpServletResponse response) throws JSONException, IOException {
		response.setContentType("application/json");
		GoodsReceiptDAO dao= new GoodsReceiptDAO();
		GoodsReceiptVO receiptVo = dao.setGoodsReceiptVO(jsonObject);
		dao.insertGoodsReceipt(receiptVo);
		PrintWriter out = response.getWriter();
		JSONObject jsonResponse = new JSONObject();
 	    jsonResponse.put("success", true);
 	    out.print(jsonResponse.toString());
 	    out.flush();
		
    }
	
	public void updateGoodsReceipt(JSONObject jsonObject, HttpServletResponse response) throws JSONException, IOException {
		response.setContentType("application/json");
		GoodsReceiptDAO dao= new GoodsReceiptDAO();
		GoodsReceiptVO receiptVo = dao.setGoodsReceiptVO(jsonObject);
		dao.updateGoodsReceipt(receiptVo);
		PrintWriter out = response.getWriter();
		JSONObject jsonResponse = new JSONObject();
 	    jsonResponse.put("success", true);
 	    out.print(jsonResponse.toString());
 	    out.flush();
		
    }
	
	public void deleteGoodsReceipt(String receiptId, HttpServletResponse response) throws IOException, SQLException, JSONException{
		response.setContentType("application/json");
	    PrintWriter out = response.getWriter();
	    GoodsReceiptDAO dao= new GoodsReceiptDAO();
	    boolean success = dao.deleteGoodsReceipt(receiptId);
	    JSONObject jsonResponse = new JSONObject();
	    jsonResponse.put("success", success);
	    jsonResponse.put("receiptId", receiptId);
	    out.print(jsonResponse.toString());
	    out.flush(); 
	}
	
}
