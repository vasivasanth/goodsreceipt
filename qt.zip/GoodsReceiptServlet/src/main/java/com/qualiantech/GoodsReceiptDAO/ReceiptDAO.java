package com.qualiantech.GoodsReceiptDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



public class ReceiptDAO {
	private static final String URL = "jdbc:postgresql://localhost:5432/erp";
    private static final String USER = "postgres";
    private static final String PASSWORD = "";
    private static Connection connection=null;
    
    //open connection
    public static boolean openConnection() {
    	try {
    		if(connection == null || connection.isClosed()) {
    			Class.forName("org.postgresql.Driver");
    		   connection = DriverManager.getConnection(URL, USER, PASSWORD);
    		}
    		return true;
    	}
    	catch(Exception e) {
            e.printStackTrace();
            return false;
    	}

     }
    
    //close connection
    public static boolean closeConnection() {
    	try {
    		if(connection != null || !connection.isClosed()) {
    			connection.close();
    		}
    		return true;
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	    return false;	
    	}
    }
    
    //set data to receiptVO
	public ArrayList<ReceiptVO> receiptVO(int limit, int offset){ 	
	    if (!openConnection()) {
	       throw new RuntimeException("Failed to open database connection.");
	     }
	    ArrayList<ReceiptVO> receiptVO = new   ArrayList<ReceiptVO>();
	    String sql = "select vendor.name, * from m_inout join vendor on m_inout.vendor_id = vendor.vendor_id order by m_inout.updated desc limit ? offset ?";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);)
    	{
    		 stmt.setInt(1, limit);
			 stmt.setInt(2, offset);
			 ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	            	ReceiptVO r=new ReceiptVO();
	            	r.setVendorId(rs.getString(1));
	            	r.setReceiptId(rs.getString("document_id"));
	            	r.setDate(rs.getDate("document_Date").toLocalDate());
	            	receiptVO.add(r);
	            }
	            return receiptVO;
    	}catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    	return null;              
 }
	
	//Receipts count
    public int receiptCount() throws SQLException {
    	 if (!openConnection()) {
  	       throw new RuntimeException("Failed to open database connection.");
  	     }
    	 String sql="select count(*) from m_inout";
    	 try(Statement stmt = connection.createStatement()){ 
    		 ResultSet rs = stmt.executeQuery(sql);
    		 rs.next();
    		 return rs.getInt(1);
    	 }
    	 catch(SQLException e) {
    		 e.printStackTrace();
    	 }
    	 finally {
    		 closeConnection();
    	   }
       return 0;
    } 
	
   //receiptLineitemVO
    public ArrayList<ReceiptLineItemVO> receiptLineItemVO(String receiptID){ 	
	    if (!openConnection()) {
	       throw new RuntimeException("Failed to open database connection.");
	     }
	    ArrayList<ReceiptLineItemVO> receiptLineItemVO = new   ArrayList<ReceiptLineItemVO>();
	    String sql = "select product.name,expiry_date,quantity from m_inoutline "
	    		      + "join product on m_inoutline.product_id=product.product_id "
	    		      + "join m_inout on m_inoutline.m_inout_id=m_inout.m_inout_id "
	    		      + "where m_inout.document_id=?";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);){
    		 stmt.setString(1, receiptID);
			 ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	            	ReceiptLineItemVO r=new ReceiptLineItemVO();
	            	r.setProductId(rs.getString(1));
	            	if (rs.getDate(2) != null) {
	            		r.setDate(rs.getDate(2).toLocalDate());
                    } else {
                        r.setDate(null);
                    }

	            	r.setQuantity(rs.getInt(3));;
	            	receiptLineItemVO.add(r);
	            }
	            return receiptLineItemVO;
    	}catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }
    	return null;              
     } 
    
    public boolean deleteReceipt(String deleteReceiptID) throws SQLException {
    	 if (!openConnection()) {
  	       throw new RuntimeException("Failed to open database connection.");
  	     }
    	  String sql="delete from m_inout where document_id = ?";
    	  try(PreparedStatement updateStmt = connection.prepareStatement(sql)){
    		  updateStmt.setString(1, deleteReceiptID);
    		  int check=updateStmt.executeUpdate();
    		  return check>0;
    	  } catch(Exception e) {
    		  e.printStackTrace();
    	  }finally {
    		  closeConnection();
    	  }
    	  return false;
    }
    
    
    public  Map<String, String[]> productMap = new LinkedHashMap<>();

    public void storeProductInMap() {
       if (!openConnection()) {
   	       throw new RuntimeException("Failed to open database connection.");
   	   }
       String sql = "select code, name, uom from product order by code asc";
       try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
            	String a[]=new String[2];
                String productId = rs.getString(1);
                a[0]=rs.getString(2);
                a[1]=rs.getString(3);
                productMap.put(productId, a);
            }
        }
      catch (SQLException e) {
         e.printStackTrace();
      }finally {
		  closeConnection();
	  }
    }
    
  
    //Store and retrieve vendor values
    public  Map<String, String> vendorMap = new LinkedHashMap<>();
    
    public void storeVendorInMap() {
    	if (!openConnection()) {
    	       throw new RuntimeException("Failed to open database connection.");
    	   }
    	String sql = "select code, name from vendor";
    	try(PreparedStatement stmt = connection.prepareStatement(sql);
    		ResultSet rs=stmt.executeQuery() ){
    		while(rs.next()) {
    			String vendorId = rs.getString(1);
    			String vendorName = rs.getString(2);
    			vendorMap.put(vendorId, vendorName);
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
  		  closeConnection();
  	  }	
    }
    
  //Insert into database
    
    //set the receipt data into VO
    public ReceiptVO setReceiptData(JSONObject jsonObject) throws JSONException {       
        ReceiptVO rv = new ReceiptVO();
        rv.setCreatedby("vasanth");
        rv.setUpdatedby("vasanth");
        rv.setReceiptId(jsonObject.getString("receiptID"));
        rv.setVendorId(jsonObject.getString("selectedVendor").split(" ")[0]);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        rv.setDate(LocalDate.parse(jsonObject.getString("receiptDate"), formatter));

        JSONArray products = jsonObject.getJSONArray("products");
        DateTimeFormatter expiryFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        List<ReceiptLineItemVO> lineItems = new ArrayList<>();
        for (int i = 0; i < products.length(); i++) {
            JSONObject product = products.getJSONObject(i);
            ReceiptLineItemVO rl = new ReceiptLineItemVO();
            rl.setCreatedby("vasanth");
            rl.setUpdatedby("vasanth");
            rl.setProductId(product.getString("productName").split(" ")[0]);
            String expiryDateStr = product.getString("expiryDate").trim();
            if (!expiryDateStr.isEmpty()) {
                rl.setDate(LocalDate.parse(expiryDateStr, expiryFormatter));
            } else {
                rl.setDate(null); // or handle as per your requirement
            }
            rl.setQuantity(Integer.parseInt(product.getString("quantity")));
            lineItems.add(rl);
        }
        rv.setLineItems(lineItems);
        return rv;   
    }
    
    
    public void insertIntoDatabase(ReceiptVO dao) {
    	String insertReceiptQuery="insert into m_inout (createdby, updatedby, document_id, document_date, vendor_id)\n"
    		            	  + "values(?,?,?,?,(select vendor_id from vendor where code = ? ))";
    	
    	
    	String insertLineItemQuery="insert into m_inoutline (createdby, updatedby, m_inout_id, product_id, expiry_date, quantity)\n"
    			               + "values(?, ?, (select m_inout_id from m_inout where document_id = ?), (select product_id from product where code=?), ?, ?)";
    	if (!openConnection()) {
 	       throw new RuntimeException("Failed to open database connection.");
 	    }
    	openConnection();
        try (
            PreparedStatement receiptStmt = connection.prepareStatement(insertReceiptQuery);
            PreparedStatement lineItemStmt = connection.prepareStatement(insertLineItemQuery);
        ) {
        	connection.setAutoCommit(false);
            Date sqlDate = Date.valueOf(dao.getReceiptDate());
        	
            // Insert DAO information into inout table
            receiptStmt.setString(1, "vasanth");
            receiptStmt.setString(2, "vasanth");
            receiptStmt.setString(3, dao.getReceiptId());
            receiptStmt.setDate(4, sqlDate);
            receiptStmt.setString(5, dao.getVendorId());
            receiptStmt.executeUpdate(); 

            // Insert line items into inoutline table
           for (ReceiptLineItemVO item : dao.getLineItems()) {
        	   Date expiryDate = (item.getDate() != null) ? Date.valueOf(item.getDate()) : null;
                lineItemStmt.setString(1, "vasanth");
                lineItemStmt.setString(2, "vasanth");
                lineItemStmt.setString(3, dao.getReceiptId());
                lineItemStmt.setString(4, item.getProductId());    
                if (expiryDate != null) {
                    lineItemStmt.setDate(5, expiryDate);
                } else {
                    lineItemStmt.setNull(5, java.sql.Types.DATE);
                }
                lineItemStmt.setInt(6, item.getQuantity());
                lineItemStmt.addBatch(); 
            }
            lineItemStmt.executeBatch();
            connection.commit();
            System.out.println("Data inserted successfully."); 

        } catch (SQLException e) {
            e.printStackTrace();
            try {connection.rollback();}
            catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
        }
        finally {
            try {
                connection.setAutoCommit(true);
                closeConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
     }
    
}
