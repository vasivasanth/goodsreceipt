package com.qualiantech.dao;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ReceiptLineItem {
	private String inoutlineId;
	private char isactive;
    private LocalDateTime created;
	private String createdby;
	private LocalDateTime updated;
	private String updatedby;
	private String receiptId;
	private String productId;
	private LocalDate date;
    private int quantity;
	
    public ReceiptLineItem() {}
	public ReceiptLineItem(String productId, LocalDate date, int quantity) {
		  this.productId = productId;
		  this.date = date;
		  this.quantity = quantity;
	  }

	  public void setInoutlineId(String inoutlineId) {this.inoutlineId = inoutlineId;} 
	  public void setIsactive(char isactive) {this.isactive=isactive;}
	  public void setCreated(LocalDateTime created) {this.created=created;}
	  public void setCreatedby(String createdby) {this.createdby=createdby;}
	  public void setUpadted(LocalDateTime updated) {this.updated=updated;}
	  public void setUpdatedby(String updatedby) {this.updatedby=updatedby;}
	  public void setReceiptId(String receiptId) {this.receiptId=receiptId;}
	  public void setProductId(String productId) {this.productId=productId;}
	  public void setDate(LocalDate date) {this.date=date;}
	  public void setQuantity(int quantity) {this.quantity=quantity;}
	  
	  
	  public String getInoutlineId() {return inoutlineId;}
	  public char getIsactive() {return isactive;}
	  public LocalDateTime getCreated() {return created;}
	  public String getCreatedby() {return createdby;}
	  public LocalDateTime getUpdated() {return updated;}
	  public String getUpdatedby() {return updatedby;}
	  public String getReceiptId() {return receiptId;}
	  public String getProductId() {return productId;}
	  public LocalDate getDate() {return date;};
	  public int getQuantity() {return quantity;};
}
