package hello;

public class ExceptionHandlingExample {

	public static void main(String[] args) {
      try {
         String s ="vasanth";
         if(s.length() != 11) {
        	 throw new UserDefinedException("length is not correct");
         }
         else {
        	 System.out.println(s.length()+" Else Part");
         }
      }
      catch(UserDefinedException use) {
    	  System.out.println(use.getMessage()); 
      }
	}

}
