package com.qualiantech.GoodsReceiptServlet;
import com.qualiantech.GoodsReceiptDAO.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

//@WebServlet("/Servlet1")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Servlet1() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out= response.getWriter();
		int page=1;
		int recordsPerPage=2;
		if (request.getParameter("page") != null) {
            try {
                page = Integer.parseInt(request.getParameter("page"));
            } catch (NumberFormatException e) {
                page = 1;
            }
        }
        int start = (page - 1) * recordsPerPage;
        
		try {
			ReceiptDAO receiptDao = new ReceiptDAO();
			int totalRecords  = receiptDao.receiptCount();
			int totalPages = (int) Math.ceil(totalRecords * 1.0 / recordsPerPage);
			ArrayList<ReceiptVO> receiptVO = receiptDao.receiptVO(recordsPerPage, start);
			out.println("<html><head><title>Product Table</title><link rel=\"stylesheet\" href=\"style.css\"><script src=\"https://kit.fontawesome.com/1026cb4533.js\" crossorigin=\"anonymous\"></script></head><body>");
            out.println("<h1>Goods Receipts</h1>  <table border=\"1\">");
            out.println("<thead><tr class=\"tableHeader\">\n"
            		+ "<th id=\"th1\">S No</th>\n"
            		+ "<th id=\"th2\">Receipt Id</th>\n"
            		+ "<th id=\"th3\">Receipt Date</th>\n"
            		+ "<th id=\"th4\">Vendor</th>\n"
            		+ "<th id=\"th5\">Action</th>\n"
            		+ "</tr> </thead> <tbody>");
            int c=0;
            for(ReceiptVO rv:receiptVO) {
            	out.println("<tr> <td>"+(++c)+"</td>"
            		    + "<td>"+rv.getReceiptId()+"</td>"
                        + "<td>"+rv.getReceiptDate()+"</td>"
                        + "<td>"+rv.getVendorId()+"</td>"
                        + "<td class=\"action\">"
                        + "<i onclick=\"view(this)\" title=\"view\" class=\"fa-solid fa-eye\"></i>"
                        + "<i title=\"edit\" class=\"fa-solid fa-pen-to-square\"></i>"
                        + "<i title=\"delete\" class=\"fa-solid fa-trash\"></i>"
                        + "</td></tr>"); 
            }
            out.println("</tbody></table><center>");
            
            if (page > 1) {
                out.println("<a href='receipts?page=" + (page - 1) + "'>Previous</a> ");
            }

            for (int i = 1; i <= totalPages; i++) {
                out.println("<a href='receipts?page=" + i + "'>" + i + "</a> ");
            }

            if (page < totalPages) {
                out.println("<a href='receipts?page=" + (page + 1) + "'>Next</a> ");
            }
            
            out.println("</center>"
            		+ " <div id=\"list-overlay\" class=\"hidden\" style=\"display: none;\"></div>"
            		+ "<div id=\"list-popupDialog\" class=\"hidden\" style=\"display: none;\">"
            		+ "<h1>Goods Receipt</h1>"
            		+ "<div id=\"reciptdata\">"
            		+ "<p id=\"id\"></p>"
            		+ "<p id=\"date\"></p>"
            		+ "<p id=\"vendor\"></p>"
            		+ "</div>"
            		+ " <table id=\"viewTable\"><thead>\n"
            		+ "    <tr class=\"table-header\">\n"
            		+ "         <th id=\"viewSno\">S No</th>\n"
            		+ "         <th id=\"viewProduct\">Product</th>\n"
            		+ "         <th id=\"viewEdate\">Expiry Date</th>\n"
            		+ "         <th id=\"viewRq\">Received Quantity</th>\n"
            		+ "         </tr>\n"
            		+ "    </thead>\n"
            		+ "<tbody id=\"viewTableBody\"></tbody></table>"
            		+ " </div>"
            		+ " <script src=\"script.js\" defer></script></body></html>");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        ReceiptDAO receiptDao = new ReceiptDAO();
        String receiptID = request.getParameter("receiptID");
        JSONArray jsonArray = new JSONArray();
        if (receiptID != null && !receiptID.isEmpty()) {
            ArrayList<ReceiptLineItemVO> receiptLineItems = receiptDao.receiptLineItemVO(receiptID);
            try {
                for (ReceiptLineItemVO item : receiptLineItems) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("productId", item.getProductId());
                    jsonObject.put("date", item.getDate());
                    jsonObject.put("quantity", item.getQuantity());
                    jsonArray.put(jsonObject);
                }
                }catch(Exception e){
                	e.printStackTrace();
                } 
                out.println(jsonArray.toString());
             }
        else {
        	out.println("[]");
        }
   }

}


/*
 StringBuilder json = new StringBuilder();
            
            json.append("[");
            for (int i = 0; i < receiptLineItems.size(); i++) {
                ReceiptLineItemVO item = receiptLineItems.get(i);
                json.append("{");
                json.append("\"productId\": \"" + item.getProductId() + "\",");
                json.append("\"date\": \"" + item.getDate() + "\",");
                json.append("\"quantity\": " + item.getQuantity());
                json.append("}");
                if (i < receiptLineItems.size() - 1) {
                    json.append(",");
                }
            }
            json.append("]");
            
        } else {
            out.println("[]"); 
        }
  [
    {
        "productId": "P001",
        "date": "2024-07-26",
        "quantity": 10
    },
    {
        "productId": "P002",
        "date": "2024-07-27",
        "quantity": 20
    }
  ] 
 */


