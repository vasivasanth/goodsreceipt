package hello;
import java.util.Scanner;

class GroceryShop{
    static Scanner sc = new Scanner(System.in);
    static String[] productList={"101-Mango", "102-Apple", "103-Orange", "104-Papaya", "105-Carrot"};
    static int[] productPrice={125,345,122,105,150};    
    static int userInput=0;
    static int totalAmount = 0;
    
    
    
    static void printLine1(){
        System.out.println("  -----------------------");
        System.out.println("  Enter 1 For Buy Product");
        System.out.println("  Enter 2 For Exit");
        System.out.println("  -----------------------");
        System.out.print("  Enter a Number: ");
        userInput = sc.nextInt();     	
    	switchFunction(userInput); 
    }
    
    static void addProduct(){
       System.out.print("  Enter Product ID: ");
       userInput = sc.nextInt();
       
       int selectedProductPrice = productPrice[userInput-101];
       
       System.out.print("  Enter quantity of Product: ");
       userInput = sc.nextInt();
       
       int showPrice = selectedProductPrice * userInput;
       totalAmount += showPrice;
       System.out.println("  Selected Product total price: "+ showPrice);
       System.out.println("  -------------------------------");    
       System.out.println("  Add Another Product for Enter 1");
       System.out.println("  Bill for Enter 3");  
       System.out.println("  -------------------------------");   
       System.out.print("  Enter a Number: "); 
       userInput = sc.nextInt();          
       switchFunction(userInput); 
              
    }
    
    static void bill(){
    
       System.out.println("  Total Amount: "+ totalAmount+" ₹" );
       System.out.println("  ----------------------------------");
       System.out.println("  Add More Products for Enter 1");
       System.out.println("  Pay Bill for Enter 4");  
       System.out.println("  -------------------------------");   
       System.out.print("  Enter a Number: "); 
       userInput = sc.nextInt(); 
       switchFunction(userInput);                   
    }
    
    
    static void switchFunction(int a){
       switch(a){
    	   case 1:  
    	           addProduct();
    	           break;
    	   case 2: 
                   System.out.println("  Thank you");
    	           break;
    	   case 3: 
    	           bill();
    	           break;
    	   case 4: 
    	           System.out.println("  Payment Successful");
                   System.out.println("  Thank you");
    	           break;    	           
    	   default:
    	        System.out.println("----You Entered Wrong Number----");
    	        printLine1();	
    	}
    
    }

    public static void main(String[] args){
       
       GroceryShop gs = new GroceryShop();
       
       

    	System.out.println("    GROCERY SHOP   ");		
    	
    	//Print Product and price
    	for(int i=0; i<productList.length; i++){
    	   String space="";
    	   if(productList[i].length()<10){
    	   	for(int j=0; j<(10-productList[i].length()); j++){
    	   	     space+=" ";
    	   	}
    	   }
    	   System.out.println("  "+productList[i]+space+" "+productPrice[i]+" ₹ Per Kg" );		
     	}
     	printLine1();	
    }
}
