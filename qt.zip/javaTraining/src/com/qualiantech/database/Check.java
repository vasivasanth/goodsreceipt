package com.qualiantech.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import com.qualiantech.dao.GoodsReceipt;
import com.qualiantech.dao.ReceiptLineItem;

public class Check {
	private Connection connection;
	public Check(Connection connection) {
		this.connection = connection;
	}
	
	public static String convertUTCToIndiaTime(Timestamp utcTimestamp) {
        // Specify the ZoneId for India (IST)
        ZoneId indiaZoneId = ZoneId.of("Asia/Kolkata");

        // Convert UTC Timestamp to LocalDateTime
        LocalDateTime localDateTime = utcTimestamp.toLocalDateTime();

        // Convert LocalDateTime to India's timezone
        LocalDateTime localDateTimeInIndia = localDateTime.atZone(ZoneId.of("UTC"))
                                            .withZoneSameInstant(indiaZoneId)
                                            .toLocalDateTime();

        // Format the LocalDateTime for display
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS");
        return localDateTimeInIndia.format(formatter);
    }

    public static String convertToIST(ZonedDateTime utcDateTime) {
        // Convert to Indian Standard Time (IST)
        ZoneId indianZoneId = ZoneId.of("Asia/Kolkata");
        ZonedDateTime istDateTime = utcDateTime.withZoneSameInstant(indianZoneId);

        // Format the output
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String istTimestamp = istDateTime.format(formatter);

        return istTimestamp;
    }
	public void viewReceiptByDao(String userInput) {
        GoodsReceipt dao = null;
        ReceiptLineItem lineitem = null;
        String inout = "select * from m_inout where document_id = ?";
        String inoutline ="select * from m_inoutline where m_inout_id = (select m_inout_id from m_inout where document_id = ?)";

        try (PreparedStatement pstmt1 = connection.prepareStatement(inout);
             PreparedStatement pstmt2 = connection.prepareStatement(inoutline)) {

            pstmt2.setString(1, userInput);
            ResultSet rs2 = pstmt2.executeQuery();

            List<ReceiptLineItem> al = new ArrayList<>();

            while (rs2.next()) { 
                lineitem = new ReceiptLineItem();
                lineitem.setInoutlineId(rs2.getString(1));
                lineitem.setIsactive(rs2.getString(2).charAt(0));
                lineitem.setCreated(rs2.getTimestamp(3).toLocalDateTime());
                lineitem.setCreatedby(rs2.getString(4));
                lineitem.setUpadted(rs2.getTimestamp(5).toLocalDateTime());
                lineitem.setUpdatedby(rs2.getString(6));
                lineitem.setReceiptId(rs2.getString(7));
                lineitem.setProductId(rs2.getString(8));
                lineitem.setDate(rs2.getDate(9).toLocalDate());
                lineitem.setQuantity(rs2.getInt(10));
                al.add(lineitem);
            }

            pstmt1.setString(1, userInput);
            ResultSet rs1 = pstmt1.executeQuery();
            while (rs1.next()) {
                dao = new GoodsReceipt();
                dao.setInoutId(rs1.getString(1));
                dao.setIsactive(rs1.getString(2).charAt(0));
                dao.setCreated(rs1.getTimestamp(3).toLocalDateTime());
                dao.setCreatedby(rs1.getString(4));
                dao.setUpadted(rs1.getTimestamp(5).toLocalDateTime());
                dao.setUpdatedby(rs1.getString(6));
                dao.setVendorId(rs1.getString(7));
                dao.setReceiptId(rs1.getString(8));
                dao.setDate(rs1.getDate(9).toLocalDate());
                dao.setLineItems(al);
            }
                  
            System.out.println("\nReceipt ID : "+userInput+"\n");
            System.out.println(""+dao.getInoutId()+" "
            		             +dao.getIsactive()+" "
            		             +dao.getCreated()+" "
            		             +dao.getCreatedby()+" "
            		             +dao.getUpdated()+" "
            		             +dao.getUpdatedby()+" "
            		             +dao.getVendorId()+" "
            		             +dao.getReceiptId()+" "
            		             +dao.getReceiptDate()+" "); 
            System.out.println("\nLine Items: \n");
            for (ReceiptLineItem item : al) {
                System.out.println(item.getInoutlineId()+" "
                		          +item.getIsactive()+" "
                		          +item.getCreated()+" "
                		          +item.getCreatedby()+" "
                		          +item.getUpdated()+" "
                		          +item.getUpdatedby()+" "
                		          +item.getReceiptId()+" "
                		          +item.getProductId()+" "
                		          +item.getDate()+" "
                		          +item.getQuantity()); // Assuming ReceiptLineItem has a proper toString() method
            }
            System.out.println("Data stored successfully");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (DateTimeParseException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
    	DatabaseConnection dbConnection = new DatabaseConnection();
    	Connection con = dbConnection.getConnection();
    
    	Check ck=new Check(con);
    	long startTime = System.nanoTime();
    	ck.viewReceiptByDao("GR439");
    	long endTime = System.nanoTime();
    	long elapsedTimeInNanos = endTime - startTime;
        long elapsedTimeInMillis = elapsedTimeInNanos / 1_000_000; 
        System.out.println("Elapsed Time in milliseconds: " + elapsedTimeInMillis);
    }

}

